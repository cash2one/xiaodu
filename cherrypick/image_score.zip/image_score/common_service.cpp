/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file CommonService.cpp
 * @author baixueyu(com@baidu.com)
 * @date 2015/11/16 11:06:18
 * @brief 
 *  
 **/

#include "common_service.h"

void safe_exit()
{
    for (;;)
    {
        raise(SIGKILL);
    }
}

void*  listen_thread_func (void *arg)
{
    CommonService* service = (CommonService*)arg;
    int ret = 0;
    arg = NULL;
    int listen_fd = 0;

    ret = ul_openlog_r(service->servicename(), service->_logstat);
    if (ret < 0)
    {
        printf("open log in listen_thread_func fail!\n");
        safe_exit();
    }

    service->_workpool.set_sock_num(service->_conf.max_conn_num);
    service->_workpool.set_queue_len(service->_conf.epending_pool_queue_len);
    service->_workpool.set_conn_timeo(6); //一个连接6秒钟没有处理，则断开。
    service->_workpool.set_epoll_timeo(500); //

    if ((listen_fd = ul_tcplisten(service->_conf.listen_port, service->_conf.listen_port)) == -1)
    {
        ul_writelog(UL_LOG_FATAL, "create listening socket error!%d ERR(%m)",\
                service->_conf.listen_port);
        safe_exit();
        return 0;
    }

    ul_writelog(UL_LOG_TRACE, "create listening socket ok! fd:%d  port:%d",
            listen_fd, service->_conf.listen_port);

    service->_workpool.set_listen_fd(listen_fd);
    while (1)
    {
        service->_workpool.check_item();
    }
    ul_writelog(UL_LOG_FATAL, "listen_thread_func exit !");
    safe_exit();
    return 0;
}

void* service_thread_func(void *arg)
{
    ServiceWorkThread* threadinfo = (ServiceWorkThread*)arg;
    CommonService* service = threadinfo->service;

    int ret = 0;
    int handle = 0;
    int client = 0;
    bool b_keep_alive = true;

    ret = ul_openlog_r(service->servicename(), threadinfo->service->_logstat);
    if (ret < 0)
    {
        printf("open log in thread service_thread_func fail!\n");
        safe_exit();
    }
    WorkSocket socket(service->_conf.read_timeout, service->_conf.write_timeout);
    socket._req_header.version = 1;
    memcpy(socket._req_header.provider, service->servicename(), 6);    
    socket._req_header.provider[6] = 0;
    socket._req_header.magic_num = NSHEAD_MAGICNUM;
    for (;;)
    {
        try
        {
            b_keep_alive = true;
            if (service->_workpool.fetch_item(&handle, &client) != 0)
            {
                continue;
            }

            int on = 1;
            setsockopt(client, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on));
            socket.attach(client);
            //交由特定的服务处理模块处理
            if (threadinfo->handler->handle(socket) < 0)
            {
                b_keep_alive = false;
            }

        }
        catch (...)
        {
            service->_workpool.reset_item(handle, false);
        }
        service->_workpool.reset_item(handle, b_keep_alive);
    }

    safe_exit();
    return NULL;
}

int CommonService::run()
{
    // ignore SIGPIPE
    signal(SIGPIPE, SIG_IGN);

    int ret = ul_pthread_create(&_listenthreadid, NULL, listen_thread_func, (void*)this);
    if (ret != 0)
    {
        ul_writelog(UL_LOG_FATAL, "thread listen_thread_func create failed. [%m]");
        return -1;
    }

    for (unsigned int i = 0; i < _conf.thread_num; ++i)
    {
        ret = ul_pthread_create(&_thread_ptr[i].thread_id, NULL, service_thread_func,
                (void*)&_thread_ptr[i]);
        if (ret != 0) 
        {
            ul_writelog(UL_LOG_FATAL, "thread listen_thread_func create\
                    failed.[%m]");
            return -1;
        }
    }

    for (unsigned int i = 0; i < _conf.thread_num; ++i)
    {
        ul_pthread_join(_thread_ptr[i].thread_id, NULL);
    }

    ul_pthread_join(_listenthreadid, NULL);
    return 1;
}






















/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
