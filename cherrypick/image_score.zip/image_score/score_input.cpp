/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file score_input.cpp
 * @author baixueyu(com@baidu.com)
 * @date 2015/12/11 15:35:38
 * @brief 
 *  
 **/

#include "score_input.h"
#include "mc_pack.h"

bool ImageInput::unserials_for_recommend(mc_pack_t *mc_pack)
{

    //get link_sign1
    int ret = mc_pack_get_uint32(mc_pack, "link_sign1", &_link_sign1);
    if (ret < 0)
    {
        ul_writelog(UL_LOG_FATAL, "get link_sign1 fail");
        return false;
    }
    ul_writelog(UL_LOG_TRACE, "get link_sign1 succ, the value is: %I10u\
            ", _link_sign1);
    //get link_sign2
    ret = mc_pack_get_uint32(mc_pack, "link_sign2", &_link_sign2);
    if (ret < 0)
    {
        ul_writelog(UL_LOG_FATAL, "get link_sign2 fail");
        return false;
    }
    ul_writelog(UL_LOG_TRACE, "get link_sign2 succ, the value is: %I10u\
        ", _link_sign2);
    
    //get site_image_link
    const char *site_image_link_temp = mc_pack_get_str(mc_pack, "site_image_link");
    int site_image_link_len = strlen(site_image_link_temp) + 1;
    if (MC_PACK_PTR_ERR(site_image_link_temp))
    {
        ul_writelog(UL_LOG_FATAL, "get site_image_link fail,");
        return false;
    }
    snprintf(_site_image_link, site_image_link_len, "%s", site_image_link_temp);
    ul_writelog(UL_LOG_TRACE, "get link succ, the site_image_link is: %s\
        ", _site_image_link);
    
    //get image raw data
    const char *raw_data_temp = (char*)mc_pack_get_raw(mc_pack, "image_raw_data", &_data_len); 
    if (MC_PACK_PTR_ERR(raw_data_temp))
    {
        ul_writelog(UL_LOG_FATAL, "get image_raw_data fail");
        return false;
    }
    memcpy(_image_raw_data, raw_data_temp, _data_len);
    _image_raw_data[_data_len] = '\0';
    ul_writelog(UL_LOG_TRACE, "get image_raw_data succ");
    
    return true;
}

bool ImageInput::unserials_for_wise(mc_pack_t *mc_pack)
{
    const char *link_temp = mc_pack_get_str(mc_pack, "link");
    int link_len = strlen(link_temp) + 1;
    if (MC_PACK_PTR_ERR(link_temp))
    {
        ul_writelog(UL_LOG_FATAL, "mcpack get link failed!");
        return false;
    }
    memcpy(_link, link_temp, link_len);
    ul_writelog(UL_LOG_TRACE, "get link succ, the link is: %s", _link);

    //get image raw data
    const char *raw_data_temp = (char*)mc_pack_get_raw(mc_pack, "image_raw_data", &_data_len); 
    if (MC_PACK_PTR_ERR(raw_data_temp))
    {
        ul_writelog(UL_LOG_FATAL, "get image_raw_data fail");
        return false;
    }
    memcpy(_image_raw_data, raw_data_temp, _data_len);
    _image_raw_data[_data_len] = '\0';
    ul_writelog(UL_LOG_TRACE, "get image_raw_data succ");

    return true;
}

bool ImageInput::unserials_for_pc(mc_pack_t *mc_pack)
{
    const char *link_temp = mc_pack_get_str(mc_pack, "link");
    int link_len = strlen(link_temp) + 1;
    if (MC_PACK_PTR_ERR(link_temp))
    {
        ul_writelog(UL_LOG_FATAL, "mcpack get link failed!");
        return false;
    }
    memcpy(_link, link_temp, link_len);
    ul_writelog(UL_LOG_TRACE, "get link succ, the link is: %s", _link);

    int ret = mc_pack_get_uint32(mc_pack, "db_type", &_db_type);
    if (ret < 0)
    {
        ul_writelog(UL_LOG_FATAL, "mcpack get db_type failed!");
        return false;
    }
    ul_writelog(UL_LOG_TRACE, "get db_type succ, the value is: %d", _db_type);

    //get link_sign1
    ret = mc_pack_get_uint32(mc_pack, "link_sign1", &_link_sign1);
    if (ret < 0)
    {
        ul_writelog(UL_LOG_FATAL, "get link_sign1 fail");
        return false;
    }
    ul_writelog(UL_LOG_TRACE, "get link_sign1 succ, the value is: %I10u\
            ", _link_sign1);
    //get link_sign2
    ret = mc_pack_get_uint32(mc_pack, "link_sign2", &_link_sign2);
    if (ret < 0)
    {
        ul_writelog(UL_LOG_FATAL, "get link_sign2 fail");
        return false;
    }
    ul_writelog(UL_LOG_TRACE, "get link_sign2 succ, the value is: %I10u\
        ", _link_sign2);

    //get site_image_link
    const char *site_image_link_temp = mc_pack_get_str(mc_pack, "site_image_link");
    int site_image_link_len = strlen(site_image_link_temp) + 1;
    if (MC_PACK_PTR_ERR(site_image_link_temp))
    {
        ul_writelog(UL_LOG_FATAL, "get site_image_link fail,");
        return false;
    }
    snprintf(_site_image_link, site_image_link_len, "%s", site_image_link_temp);
    ul_writelog(UL_LOG_TRACE, "get link succ, the site_image_link is: %s\
        ", _site_image_link);

    //get image_link_sign1
    ret = mc_pack_get_uint32(mc_pack, "image_link_sign1", &_image_link_sign1);
    if (ret < 0)
    {
        ul_writelog(UL_LOG_FATAL, "get image_link_sign1 fail");
        return false;
    }
    ul_writelog(UL_LOG_TRACE, "get image_link_sign1 succ, the value is: %I10u\
            ", _image_link_sign1);
    //get image_link_sign2
    ret = mc_pack_get_uint32(mc_pack, "image_link_sign2", &_image_link_sign2);
    if (ret < 0)
    {
        ul_writelog(UL_LOG_FATAL, "get image_link_sign2 fail");
        return false;
    }
    ul_writelog(UL_LOG_TRACE, "get image_link_sign2 succ, the value is: %I10u\
            ", _image_link_sign2);

    //get image raw data
    const char *raw_data_temp = (char*)mc_pack_get_raw(mc_pack, "image_raw_data", &_data_len); 
    if (MC_PACK_PTR_ERR(raw_data_temp))
    {
        ul_writelog(UL_LOG_FATAL, "get image_raw_data fail");
        return false;
    }
    memcpy(_image_raw_data, raw_data_temp, _data_len);
    _image_raw_data[_data_len] = '\0';
    ul_writelog(UL_LOG_TRACE, "get image_raw_data succ");

    return true;

}

bool ImageInput::unserials(mc_pack_t *mc_pack)
{
    int ret = mc_pack_get_uint32(mc_pack, "request_type", &_request_type);
    if (ret < 0)
    {
        ul_writelog(UL_LOG_FATAL, "mcpack get request_type failed!");
        return false;
    }
    ul_writelog(UL_LOG_TRACE, "get request_type succ, the value is: %I32u", _request_type);

    if (_request_type == REQUEST_TYPE_PC || _request_type == REQUEST_TYPE_TOPQUERY)
    {
        if (!unserials_for_pc(mc_pack))
        {
            return false;
        }
    }
    else if (_request_type == REQUEST_TYPE_WISE) 
    {
        if (!unserials_for_wise(mc_pack))
        {
            return false;
        }
    }
    else if (_request_type == REQUEST_TYPE_RECOMMEND ||
            _request_type == REQUEST_TYPE_RECOMMEND_MAINPAGE) 
    {
        if (!unserials_for_recommend(mc_pack))
        {
            return false;
        }
    }
    else 
    {
        return false;
    }
    
}





















/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
