/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file CommonService.h
 * @author baixueyu(com@baidu.com)
 * @date 2015/11/16 11:06:52
 * @brief 
 *  
 **/

#ifndef  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_COMMON_SERVICE_H
#define  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_COMMON_SERVICE_H

#include "ul_log.h"
#include "ul_thr.h"
#include "ependingpool.h"
#include "ul_net.h"
#include <sys/socket.h>
#include <netinet/tcp.h>
#include "nshead.h"

class CommonService;

class WorkSocket
{
public:
    unsigned int _logid;
    nshead_t _req_header;

    WorkSocket(int readtimeout, int writetimeout)
        : _to_read_(readtimeout), _to_write_(writetimeout){}

    void attach(int socket)
    {
        _sock_ = socket;
    }

    int read(char* buf, int len)
    {
        nshead_t nshead;
        int ret = nshead_read(_sock_, &(nshead), buf, len, _to_read_, NSHEAD_CHECK_NONE);
        if (ret < 0)
        {
            ul_writelog(UL_LOG_WARNING, "get query data error! ret[%d]", ret);
            return -1;
        }
        _logid = nshead.log_id;
        return nshead.body_len;
    }

    bool write(char* buf, int len)
    {
        _req_header.log_id = _logid;
        _req_header.body_len = len;
        int ret = nshead_write_ex(_sock_, &_req_header, buf, _to_write_);
        if (ret < 0){
            ul_writelog(UL_LOG_WARNING, "error send response to ui! err[%s]", nshead_error(ret));
            return false;
        }
        return true;
    }
private:
    int _sock_;
    int _to_read_;
    int _to_write_;
};

class ServiceHandler
{
public:
    virtual int handle(WorkSocket& socket) = 0;
    virtual ~ServiceHandler(){}
};

class ServiceFactory
{
public:
    virtual ServiceHandler* create(int thread_index,  char* mysql_host, unsigned int mysql_port,
            char* mysql_user, char* mysql_passwd, char* db_name, unsigned int encode_type) = 0;
    virtual ~ServiceFactory() {}
};

const int COM_MAX_DIR_LEN = 256;

struct ServiceConfig
{
    unsigned int thread_num;
    unsigned int max_conn_num;
    int epending_pool_queue_len;
    unsigned int listen_port;
    unsigned int read_timeout;
    unsigned int write_timeout;
    unsigned int mysql_port;
    char mysql_host[16];
    char mysql_user[32];
    char mysql_passwd[32];
    char db_name[32];
    unsigned int encode_type;

};

void safe_exit();
void*  listen_thread_func (void *arg);
void*  service_thread_func (void *arg);

struct ServiceWorkThread
{
    pthread_t        thread_id;
    long            thread_count;
    ServiceHandler* handler;
    CommonService*    service;
};

class CommonService
{
public:
    ependingpool  _workpool;
    ul_logstat_t* _logstat;
    ServiceConfig _conf;
public:
    CommonService(const char* name, ServiceConfig& conf, ul_logstat_t* log)
        : _conf(conf), _logstat(log)
    {
        memcpy(_service_name, name, sizeof(_service_name));
    }

    ~CommonService()
    {
        if (_thread_ptr != NULL)
        {
            delete _thread_ptr;
            _thread_ptr = NULL;
        }
    }

    bool initialize(ServiceFactory* factory)
    {
        //1. 初始化线程结构
        if (_conf.thread_num == 0)
        {
            ul_writelog(UL_LOG_WARNING,
                "[%s:%d] work thread num cannot be NULL", __FILE__, __LINE__);
            return false;
        }
        _thread_ptr = new ServiceWorkThread[_conf.thread_num];
        if (_thread_ptr == NULL)
        {
            ul_writelog(UL_LOG_FATAL,
                "[%s:%d] Cannot alloc mem for thread_ptrs", __FILE__, __LINE__);
            return false;
        }
        //2. 初始化ServiceHandler
        for (unsigned int i = 0; i < _conf.thread_num; i++)
        {
            _thread_ptr[i].service = this;
            _thread_ptr[i].handler = factory->create(i, _conf.mysql_host, _conf.mysql_port, 
                    _conf.mysql_user, _conf.mysql_passwd, _conf.db_name, _conf.encode_type);
            if (_thread_ptr[i].handler == NULL)
            {
                ul_writelog(UL_LOG_FATAL,
                    "[%s:%d] Cannot initialize service handler", __FILE__, __LINE__);
                return false;
            }
        }
        return true;
    }
    int run();

    const char* servicename()
    {
        return &_service_name[0];
    }

private:
    ServiceWorkThread    *_thread_ptr;
    pthread_t    _listenthreadid;
    char _service_name[256];
};

#endif  //__COMMONSERVICE_H_

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
