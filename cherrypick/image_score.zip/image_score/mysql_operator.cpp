/***************************************************************************
 * 
 * Copyright (c) 2011 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file indexdb_db_operator.cpp
 * @author lizhiwei01(lizhiwei01@baidu.com)
 * @date 2011/02/09 18:47:49
 * @brief 
 *  
 **/

#include "mysql_operator.h"

#include "ub.h"

Indexdboperator::Indexdboperator()
{
    _operator = NULL;
    _ip[0] = 0;
    _port = 0;
    _user[0] = 0;
    _password[0] = 0;
}

Indexdboperator::~Indexdboperator()
{
    close();
}

int Indexdboperator::init(const char* ip, const unsigned int port,
        const char* user, const char* pass, const char* db_name,
        const int encode_type)
{
    snprintf(_ip, IP_LEN, "%s", ip);
    //strncpy(_ip, ip, IP_LEN);
    _ip[IP_LEN - 1] = 0;
    snprintf(_user, sizeof(_user), "%s", user);
    snprintf(_password, sizeof(_password), "%s", pass);
    snprintf(_db_name, sizeof(_db_name), "%s", db_name);
    _port = port;
    _encode_type = encode_type;
    return connect();
}

int Indexdboperator::ping()
{
    if (_operator != NULL && 0 == mysql_ping(_operator))
    {
        return 0;
    }
    close();
    return connect();
}

int Indexdboperator::connect()
{
    if (_operator == NULL)
    {
        _operator = mysql_init(NULL);
        if (_operator == NULL)
        {
            UB_LOG_WARNING("mysql init fail.");
            return -1;
        }
    }
    if (NULL == mysql_real_connect(_operator, _ip, _user, _password, _db_name,
                _port, NULL, 0))
    {
        UB_LOG_WARNING("connect mysql fail,ip:%s,port:%uh,user:%s,pass:%s,db:%s",
                _ip, _port, _user, _password, _db_name);
        close();
        return -1;
    }
    if (_encode_type == INDEXDB_ENCODING_UTF8)
    {
        if (mysql_set_character_set(_operator, "utf8")!=0)
        {
            UB_LOG_WARNING("set character fail.");
            close();
            return -1;
        }
    }
    else if (_encode_type == INDEXDB_ENCODING_GBK)
    {
        if (mysql_set_character_set(_operator, "gbk")!=0)
        {
            UB_LOG_WARNING("set character fail.");
            close();
            return -1;
        }
    }
    else
    {
        UB_LOG_WARNING("encode_type not support.");
        close();
        return -1;
    }
    if (mysql_autocommit(_operator, 1))
    {
        UB_LOG_WARNING("set autocommit fail.");
        close();
        return -1;
    }
    return 0;
}

void Indexdboperator::close()
{
    if (_operator)
    {
        mysql_close(_operator);
    }
    _operator = NULL;
}

int Indexdboperator::commit()
{
    if (_operator == NULL)
    {
        UB_LOG_WARNING("mysql commit fail, operator[NULL]");
        return -1;
    }
    if (mysql_commit(_operator))
    {
        UB_LOG_WARNING("mysql commit fail,error_str[%s].", mysql_error(_operator));
        return -1;
    }
    return 0;
}

int Indexdboperator::rollback()
{
    if (_operator == NULL)
    {
        UB_LOG_WARNING("mysql rollback fail, operator[NULL]");
        return -1;
    }
    if (mysql_rollback(_operator))
    {
        UB_LOG_WARNING("mysql rollback fail,error_str[%s].", mysql_error(_operator));
        close();
        return -1;
    }
    return 0;
}

int Indexdboperator::sendquery(const char* query, const int query_len)
{
    int query_status = 0;
    UB_LOG_DEBUG("mysql exec[%s]", query);
    if (_operator == NULL)
    {
        UB_LOG_WARNING("sendquery fail, operator[NULL]");
        return -1;
    }
    if ((query_status = mysql_real_query(_operator, query, query_len)))
    {
        UB_LOG_WARNING("send query[%s] fail, error_str[%s]", query, mysql_error(_operator));
        return -1;
    }
    return 0;
}






/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
