/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file score_input.h
 * @author baixueyu(com@baidu.com)
 * @date 2015/12/11 15:31:04
 * @brief 
 *  
 **/

#ifndef  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_SCORE_INPUT_H
#define  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_SCORE_INPUT_H

#include "score_define.h"
#include "mc_pack.h"

class ImageInput
{
public:
    unsigned int _request_type;
    char _link[SITE_LEN];
    unsigned int _link_sign1; 
    unsigned int _link_sign2;
    unsigned int _db_type;
    unsigned int _data_len; 
    char _site_image_link[SITE_LEN];
    unsigned int _image_link_sign1;
    unsigned int _image_link_sign2;
    char _image_raw_data[DATA_LEN];
    mc_pack_t _trans_data;

    bool unserials(mc_pack_t *mc_pack);
    bool unserials_for_pc(mc_pack_t *mc_pack);
    bool unserials_for_wise(mc_pack_t *mc_pack);
    bool ImageInput::unserials_for_recommend(mc_pack_t *mc_pack);
    ImageInput()
    {
        _request_type = 0;
        memset(_link, 0, sizeof(_link));
        _link_sign1 = 0;
        _link_sign2 = 0;
        _db_type = 0;
        memset(_site_image_link, 0, sizeof(_site_image_link));
        _image_link_sign1 = 0;
        _image_link_sign2 = 0;
        memset(_image_raw_data, 0, sizeof(_image_raw_data));
    }
    ~ImageInput()
    {
    }
};














#endif  //__SCORE_INPUT_H_

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
