/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file image_score.cpp
 * @author baixueyu(com@baidu.com)
 * @date 2015/11/10 20:07:14
 * @brief 
 *  
 **/
#include "image_score.h"
#include "score_service_handler.h"

ScoreConfig g_conf;

void read_log_conf(Ul_confdata* pcf, LogConfig* pconf)
{
    //2. ��ȡlog��Ϣ����log
    if (!ul_getconfstr(pcf, "LOG_PATH", pconf->logpath))
    {
        snprintf(pconf->logpath, SCORE_MAX_DIR_LEN, "./log");
    }
    if (!ul_getconfstr(pcf, "LOG_NAME",  pconf->logname))
    {
        snprintf(pconf->logname, SCORE_MAX_DIR_LEN, "%s", "defaultlog.");
    }
    if (!ul_getconfint(pcf, "LOG_LEVEL", &(pconf->loglevel)))
    {
        pconf->loglevel = UL_LOG_ALL;
    }
    if (!ul_getconfint(pcf, "LOG_SIZE", &(pconf->logsize)))
    {
        pconf->logsize = 500000;
    }

    pconf->log_stat.events = pconf->loglevel;
    pconf->log_stat.spec = 0;
    pconf->log_stat.to_syslog = 0;
}

bool read_service_conf(Ul_confdata *pcf, ServiceConfig* pconf)
{
    if (!ul_getconfuint(pcf, "THREAD_NUM", &(pconf->thread_num)))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [THREAD_NUM] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set THREAD_NUM %d.", pconf->thread_num);

    if (!ul_getconfuint(pcf, "max_conn_num", &(pconf->max_conn_num)))
    {
        pconf->max_conn_num = 500;
    }
    ul_writelog(UL_LOG_NOTICE, "set max_conn_num %d.", pconf->max_conn_num);

    if (!ul_getconfint(pcf, "epending_pool_queue_len", &(pconf->epending_pool_queue_len)))
    {
        pconf->epending_pool_queue_len = 100;
    }
    ul_writelog(UL_LOG_NOTICE, "set epending_pool_queue_len %d.", pconf->epending_pool_queue_len);
    
    if (!ul_getconfuint(pcf, "listen_port", &(pconf->listen_port)))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [listen_port] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set listen_port %d.", pconf->listen_port);

    if (!ul_getconfuint(pcf, "readtimeout", &(pconf->read_timeout)))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [readtimeout] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set readtimeout %d.", pconf->read_timeout);

    if (!ul_getconfuint(pcf, "writetimeout", &(pconf->write_timeout)))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [writetimeout] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set writetimeout %d.", pconf->write_timeout);

    if (!ul_getconfuint(pcf, "mysql_port", &(pconf->mysql_port)))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [mysql_port] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set mysql_port %d.", pconf->write_timeout);
        
    if (!ul_getconfstr(pcf, "mysql_user", pconf->mysql_user))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [mysql_user] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set mysql_user %s.", pconf->mysql_user);

    if (!ul_getconfstr(pcf, "mysql_passwd", pconf->mysql_passwd))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [mysql_passwd] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set mysql_passwd %s.", pconf->mysql_passwd);
   
    if (!ul_getconfstr(pcf, "mysql_host", pconf->mysql_host))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [mysql_host] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set mysql_host %s.", pconf->mysql_host);

    if (!ul_getconfstr(pcf, "db_name", pconf->db_name))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [db_name] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set db_name %s.", pconf->db_name);

    if (!ul_getconfuint(pcf, "encode_type", &(pconf->encode_type)))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [encode_type] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set encode_type %d.", pconf->encode_type);

    return true;
}

bool readconf(Ul_confdata *pcf, ScoreConfig *pconf)
{
    if (!read_service_conf(pcf, &(pconf->svc_config)))
    {
        return false;
    }
    return true;
}

bool init(ScoreConfig * pconf)
{
     //1. ��conf�ļ�
    Ul_confdata *pcf = NULL;
    pcf = ul_initconf(100);
    if (NULL == pcf)
    {
        ul_writelog(UL_LOG_FATAL, "\n[Fatal Error] init buf for basic config file error!\n");
        return false;
    }

    int ret = ul_readconf("conf/", "score.conf", pcf);
    if (ret < 0) 
    {   
        ul_writelog(UL_LOG_FATAL, "load config file error!\n");
        return false;
    }
    //2. ��ȡlog��Ϣ����log
    read_log_conf(pcf, &(pconf->log_conf));
    ul_writelog(UL_LOG_NOTICE, "use log: path=%s file=%s\n", pconf->log_conf.logpath, 
            pconf->log_conf.logname);

    ret = ul_openlog(pconf->log_conf.logpath, pconf->log_conf.logname, 
            &(pconf->log_conf.log_stat), pconf->log_conf.logsize);  

    if (ret < 0) 
    {
        ul_writelog(UL_LOG_FATAL, "\n[Fatal Error] open log fail!\n");   
        ul_freeconf(pcf);
        return false;
    }
    if (!readconf(pcf, pconf))
    {
        ul_writelog(UL_LOG_FATAL, "\n[Fatal Error] read conf fail!\n");
        ul_freeconf(pcf);
        return false;
    }
}

void *score_service_thread(void *)
{
    char* service_name = "image_score";
    ServiceConfig score_svc_config;
    score_svc_config = g_conf.svc_config;

    ScoreServiceFactory scoresvcfactory;

    CommonService svc(service_name, score_svc_config, &g_conf.log_conf.log_stat);
    if (!svc.initialize(&scoresvcfactory))
    {
        ul_writelog(UL_LOG_FATAL,
            "aladin service initialization error");
        return NULL;
    }
    if (!svc.run())
    {
        return NULL;
    }

    return NULL;

}

int main(int argc __attribute__((unused)), char** argv __attribute__((unused)))
{
    if (!init(&g_conf))
    {
        return 1;
    }

    pthread_t scorethreadid;
    if (ul_pthread_create(&scorethreadid, NULL, score_service_thread, NULL) != 0)
    {
        ul_writelog(UL_LOG_FATAL, "thread score_service_thread create failed. [%m]");
        return 1;
    }
    ul_pthread_join(scorethreadid, NULL);
    return 0;
}





















/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
