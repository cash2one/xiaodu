/***************************************************************************
 * 
 * Copyright (c) 2011 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file indexdb_operator.h
 * @author lizhiwei01(lizhiwei01@baidu.com)
 * @date 2011/01/13 15:40:53
 * @brief 
 *  
 **/

#ifndef  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_MYSQL_OPERATOR_H
#define  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_MYSQL_OPERATOR_H
#include "mysql.h"
#include <string.h>
#include <stdio.h>

const int INDEXDB_DB_OPERATOR_BUFFER_SIZE = 1024 * 512;
const int IP_LEN = 16;
const int INDEXDB_ENCODING_UTF8 = 0;
const int INDEXDB_ENCODING_GBK = 1;

class Indexdboperator
{
    public:
        Indexdboperator();
        ~Indexdboperator();
        /**
         * @brief ³õÊ¼»¯
         *
         * @param [in] ip   : const char*
         * @param [in] port   : const uint16_t
         * @param [in] user   : const char*
         * @param [in] pass   : const char*
         * @return  int
         * @retval
         *      - =0 : success
         *      - <0 : fail
         * @see
         * @note
         * @author lizhiwei01
         * @date 2011/02/27 19:13:45
        **/
        int init(const char* ip, const unsigned int port, const char* user, const char* pass, 
                const char* db_name, const int encode_type);
        /**
         * @brief ¼ì²éÊý¾Ý¿âÁ´½ÓÊÇ·ñÕý³£
         *
         * @return  int
         * @retval
         *      - =0 : success
         *      - <0 : fail
         * @see
         * @note
         * @author lizhiwei01
         * @date 2011/02/27 19:18:35
        **/
        int ping();

        /**
         * @brief Ö´ÐÐmysql_commit
         *
         * @return  int
         * @retval
         *      - =0 : success
         *      - <0 : fail
         * @see
         * @note
         * @author lizhiwei01
         * @date 2011/02/27 19:24:07
        **/
        int commit();
        /**
         * @brief Ö´ÐÐ mysql_rollback
         *
         * @return  int
         * @retval
         *      - =0 : success
         *      - <0 : fail
         * @see
         * @note
         * @author lizhiwei01
         * @date 2011/02/27 19:24:32
        **/
        int rollback();

        /**
         * @brief Ñ¡³öÊý¾Ý£¬´æÔÚÎÄ¼þÀï
         *
         * @param [in] cols   : const bsl::deque<bsl::string>&
         * @param [in] table_name   : const char*
         * @param [in] file_name   : const char*
         * @return  int
         * @retval
         *      - >=0 : ½á¹ûÊý
         *      - <0 : fail
         * @see
         * @note
         * @author lizhiwei01
         * @date 2011/02/27 19:29:17
        **/
        int sendquery(const char* query, const int query_len);

    private:
        MYSQL *_operator;
        char _ip[IP_LEN];
        unsigned int _port;
        char _user[32];
        char _password[32];
        char _db_name[32];
        unsigned int _encode_type;

        char _buffer[INDEXDB_DB_OPERATOR_BUFFER_SIZE];

        /**
         * @brief Á¬½ÓÊý¾Ý¿â£¬ÉèÖÃ×Ô¶¯Ìá½»±êÖ¾£¬ºÍ±àÂëÀàÐÍ
         *
         * @return  int
         * @retval
         *      - =0 : success
         *      - <0 : fail
         * @see
         * @note
         * @author lizhiwei01
         * @date 2011/02/27 19:22:48
        **/
        int connect();
        /**
         * @brief ¹Ø±ÕÊý¾Ý¿âÁ¬½Ó
         *
         * @return  void
         * @retval
         *      - =0 : success
         *      - <0 : fail
         * @see
         * @note
         * @author lizhiwei01
         * @date 2011/02/27 19:23:45
        **/
        void close();
};

#endif  //__INDEXDB_DB_OPERATOR_H_

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
