/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file image_score.h
 * @author baixueyu(com@baidu.com)
 * @date 2015/11/10 20:35:14
 * @brief 
 *  
 **/
#ifndef  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_IMAGE_SCORE_H
#define  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_IMAGE_SCORE_H

#include "ul_log.h"
#include "ul_conf.h"
#include "ul_thr.h"
#include "common_service.h"

const int SCORE_MAX_DIR_LEN = 500;

struct LogConfig
{
    ul_logstat_t log_stat;
    char logpath[SCORE_MAX_DIR_LEN];
    char logname[SCORE_MAX_DIR_LEN];
    int loglevel;
    int logsize;
};

struct ScoreConfig
{
    LogConfig log_conf;
    ServiceConfig svc_config;
};

#endif  //__IMAGE_SCORE_H_

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
