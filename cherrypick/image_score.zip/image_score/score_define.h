/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file score_define.h
 * @author baixueyu(com@baidu.com)
 * @date 2015/11/25 10:12:33
 * @brief 
 *  
 **/

#ifndef  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_SCORE_DEFINE_H
#define  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_SCORE_DEFINE_H

#include "ul_log.h"

#define TIMEDIFF(s, e)  ((e.tv_sec - s.tv_sec) * 1000000 + e.tv_usec - s.tv_usec)

const int MAX_DIR_LEN = 256;
const int BUF_SIZE_REQ = 1024 * 1024;
const int BUF_SIZE_RES = 1024 * 1024;
const int SITE_LEN = 1024;
const int DATA_LEN = 1024 * 1024;

//request_type for other
const int REQUEST_TYPE_PC = 1;
const int REQUEST_TYPE_WISE = 2;
const int REQUEST_TYPE_RECOMMEND = 3;
const int REQUEST_TYPE_RECOMMEND_MAINPAGE = 4;
//request_type for myself
const int REQUEST_TYPE_TOPQUERY = 11;

//db_type
const int DB_TYPE_SPIDER = 1;
const int DB_TYPE_VIDEOMAP = 2;

// 鐢ㄥ畯灏佽鎵撳嵃鏃ュ織鐨勫嚱鏁�

#ifdef FATAL_LOG
#undef FATAL_LOG
#endif
#define FATAL_LOG(fmt, arg...) do { \
        ul_writelog(UL_LOG_FATAL, "[%s:%d]" fmt, __FILE__, __LINE__, ## arg); \
} while (0)

#ifdef WARNING_LOG
#undef WARNING_LOG
#endif
#define WARNING_LOG(fmt, arg...) do { \
        ul_writelog(UL_LOG_WARNING, "[%s:%d]" fmt, __FILE__, __LINE__, ## arg); \
} while (0)

#ifdef NOTICE_LOG
#undef NOTICE_LOG
#endif
#define NOTICE_LOG(fmt, arg...) do { \
        ul_writelog(UL_LOG_NOTICE, "[%s:%d]" fmt, __FILE__, __LINE__, ## arg); \
} while (0)

#ifdef TRACE_LOG
#undef TRACE_LOG
#endif
#define TRACE_LOG(fmt, arg...) do { \
        ul_writelog(UL_LOG_TRACE, "[%s:%d]" fmt, __FILE__, __LINE__, ## arg); \
} while (0)

#ifdef DEBUG_LOG
#undef DEBUG_LOG
#endif
#define DEBUG_LOG(fmt, arg...) do { \
        ul_writelog(UL_LOG_DEBUG, "[%s:%d]" fmt, __FILE__, __LINE__, ## arg); \
} while (0)

#endif 





/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
