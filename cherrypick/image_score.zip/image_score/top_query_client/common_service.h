/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file CommonService.h
 * @author baixueyu(com@baidu.com)
 * @date 2015/11/16 11:06:52
 * @brief 
 *  
 **/

#ifndef  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_COMMON_SERVICE_H
#define  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_COMMON_SERVICE_H

#include "ul_log.h"
#include "ul_thr.h"
#include "mc_pack.h"
#include "ependingpool.h"
#include "ul_net.h"
#include <sys/socket.h>
#include <netinet/tcp.h>
#include "nshead.h"
#include "condvar.h"
#include "send_define.h"

class CommonService;

const int COM_MAX_DIR_LEN = 256;

void safe_exit();
void*  service_thread_func (void *arg);

struct ServiceConfig
{
    unsigned int thread_num;
    char server_host[IP_LEN];
    unsigned int server_port;
    unsigned int read_timeout;
    unsigned int write_timeout;
    unsigned int encode_type;
    char file_name[DIR_LEN];
    char pic_dir[DIR_LEN];
};

//struct file_input
//{
//    unsigned int _request_type;
//    char _link[SITE_LEN];
//    uint32_t _link_sign1; 
//    uint32_t _link_sign2;
//    uint32_t _db_type;
//    char _site_image_link[SITE_LEN];
//    uint32_t _image_link_sign1;
//    uint32_t _image_link_sign2;
//    char _image_raw_data[DATA_LEN];
//    mc_pack_t _trans_data;
//    file_input()
//    {
//        _request_type = 0;
//        memset(_link, 0, sizeof(_link));
//        _link_sign1 = 0;
//        _link_sign2 = 0;
//        _db_type = 0;
//        memset(_site_image_link, 0, sizeof(_site_image_link));
//        _image_link_sign1 = 0;
//        _image_link_sign2 = 0;
//        memset(_image_raw_data, 0, sizeof(_image_raw_data));
//    }
//    file_input(unsigned int request_type, char *link, unsigned int link_sign1, unsigned int link_sign2, unsigned int db_type, 
//            char *site_image_link, unsigned int image_link_sign1, unsigned int image_link_sign2,
//            char *image_raw_data)
//    {
//        _request_type = request_type;
//        memcpy(_link, link, sizeof(_link));
//        _link_sign1 = link_sign1;
//        _link_sign2 = link_sign2;
//        _db_type = db_type;
//        memcpy(_site_image_link, site_image_link, sizeof(_site_image_link));
//        _image_link_sign1 = image_link_sign1;
//        _image_link_sign2 = image_link_sign2;
//        memcpy(_image_raw_data, image_raw_data, sizeof(_image_raw_data));
//    }
//    ~file_input()
//    { 
//    }
//
//}g_input_data[500];

class CommonService
{
public:
    int _queue_len;
    ServiceConfig _conf;
    ul_logstat_t* _logstat;
    CondVar _m_data_signal;
    int _m_state;
public:
    CommonService(const char* name, ServiceConfig& conf, ul_logstat_t* log)
        : _conf(conf), _logstat(log)
    {
        memcpy(_service_name, name, sizeof(_service_name));
        _queue_len = 0;
        _m_state = -1;
    }

    ~CommonService()
    {
    }
    int run();
    //int get_information(char *file_name, char* pic_dir, file_input *input_data);
    char* servicename()
    {
        return &_service_name[0];
    }

private:
    char _service_name[256];
};

#endif  //__COMMONSERVICE_H_

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
