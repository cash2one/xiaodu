/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file send.h
 * @author baixueyu(com@baidu.com)
 * @date 2015/12/14 16:05:43
 * @brief 
 *  
 **/

#ifndef  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_TOP_QUERY_CLIENT_SEND_H
#define  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_TOP_QUERY_CLIENT_SEND_H

#include "ul_log.h"
#include "ul_conf.h"
#include "ul_thr.h"
#include "send_define.h"
#include "common_service.h"

const int SCORE_MAX_DIR_LEN = 500;

struct LogConfig
{
    ul_logstat_t log_stat;
    char logpath[SCORE_MAX_DIR_LEN];
    char logname[SCORE_MAX_DIR_LEN];
    int loglevel;
    int logsize;
};

struct SendConfig
{
    LogConfig log_conf;
    ServiceConfig svc_config;
};

#endif  //__SEND_H_

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
