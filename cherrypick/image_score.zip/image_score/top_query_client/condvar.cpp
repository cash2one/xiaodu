#include "condvar.h"

CondVar::CondVar() 
{
    pthread_cond_init(&_m_cond_var, NULL);
}
CondVar::~CondVar()
{
    pthread_cond_destroy(&_m_cond_var);
}
void CondVar::wait(pthread_mutex_t* mutex)
{
    pthread_cond_wait(&_m_cond_var, mutex);
}
void CondVar::signal() 
{
    pthread_cond_signal(&_m_cond_var);
}
void CondVar::broadcast()
{
    pthread_cond_broadcast(&_m_cond_var);
}
