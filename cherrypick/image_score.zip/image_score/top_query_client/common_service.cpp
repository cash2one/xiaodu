/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file CommonService.cpp
 * @author baixueyu(com@baidu.com)
 * @date 2015/11/16 11:06:18
 * @brief 
 *  
 **/
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "common_service.h"
#include <iostream>
#include <fstream.h>
#include <strings.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <ul_sign.h>
#include <unistd.h>
#include "ul_thr.h"
#include <stdlib.h>
#include <vector>

pthread_mutex_t g_data_num_lock;

typedef struct file_input
{
    unsigned int i_request_type;
    char i_link[SITE_LEN];
    uint32_t i_link_sign1; 
    uint32_t i_link_sign2;
    uint32_t i_db_type;
    char i_site_image_link[SITE_LEN];
    uint32_t i_image_link_sign1;
    uint32_t i_image_link_sign2;
    char i_image_raw_data[DATA_LEN];
    mc_pack_t i_trans_data;
    file_input()
    {
        i_request_type = 0;
        memset(i_link, 0, sizeof(i_link));
        i_link_sign1 = 0;
        i_link_sign2 = 0;
        i_db_type = 0;
        memset(i_site_image_link, 0, sizeof(i_site_image_link));
        i_image_link_sign1 = 0;
        i_image_link_sign2 = 0;
        memset(i_image_raw_data, 0, sizeof(i_image_raw_data));
    }
    void data_input(unsigned int request_type, char *link, unsigned int link_sign1,
            unsigned int link_sign2, unsigned int db_type, char *site_image_link, 
            unsigned int image_link_sign1, unsigned int image_link_sign2)
    {
        i_request_type = request_type;
        //memcpy(_link, link, sizeof(_link));
        snprintf(i_link, sizeof(i_link), "%s", link);
        i_link_sign1 = link_sign1;
        i_link_sign2 = link_sign2;
        i_db_type = db_type;
        snprintf(i_site_image_link, sizeof(i_site_image_link), "%s", site_image_link);
        i_image_link_sign1 = image_link_sign1;
        i_image_link_sign2 = image_link_sign2;
        //memcpy(i_image_raw_data, image_raw_data, sizeof(i_image_raw_data));
        //snprintf(_image_raw_data, sizeof(_image_raw_data), "%s", image_raw_data);
    }
    ~file_input()
    { 
    }
};

std::vector<file_input> g_file_input;

struct crawl_arg
{
    char ip[IP_LEN];
    unsigned int port;
    int readtimeout;
    int writetimeout;
    CondVar m_data_signal;
    int *m_state;
};

void safe_exit()
{
    for (;;)
    {
        raise(SIGKILL);
    }
}

int make_key(const char* buf_url, uint32_t & sign1, uint32_t & sign2)
{
    if (buf_url == NULL)
    {
        return -1; 
    }   

    char buf[10240];
    int length = snprintf(buf, sizeof(buf), "%s", buf_url);
    if (length < 0) {
        return -1;    
    } else {
        if (creat_sign_fs64(buf, length, &sign1, &sign2) !=1) {
            return -1; 
        }   
    }   

    return 0;
}

bool get_image_sign(char *image_link_url, unsigned int &_image_link_sign1, 
        unsigned int &_image_link_sign2)
{
    std::string link_url = image_link_url;
    int url_len = strlen(image_link_url);
    int sign_begin = 0;
    int sign_end = 0;

    char *u = "u";
    char *u1 = "=";
    char *f = "&";
    char *f1 = "f";
    char url[3];
    char url1[3];

    for (int i = 0; i < url_len; i++)
    {
        snprintf(url, 2, "%s", image_link_url + i);
        snprintf(url1, 2, "%s", image_link_url + i + 1);

        if (strcmp(url, u) == 0 && strcmp(url1, u1) == 0)
        {
            sign_begin = i + 2;
        }
        if (strcmp(url, f) == 0 && strcmp(url1, f1) == 0)
        {
            sign_end = i - sign_begin;
            break;
        } 
    }

    char temp_sign_str[22] = "\0";
    char temp_image_link_sign1[11] = "\0";
    char temp_image_link_sign2[11] = "\0";

    snprintf(temp_sign_str, sign_end + 2, "%s", link_url.substr(sign_begin).c_str());
    std::string temp_string_str = temp_sign_str;
    int idx = temp_string_str.find(",");
    if (idx == -1)
    {
        ul_writelog(UL_LOG_WARNING, "get image_link_url has some problem!\
                , image_url: %s", image_link_url);
        return false;
    }
    snprintf(temp_image_link_sign1, idx + 2, "%s", temp_sign_str);
    snprintf(temp_image_link_sign2, idx + 2, "%s", temp_sign_str + idx + 1);
    _image_link_sign1 = strtoul(temp_image_link_sign1, 0, 0);
    _image_link_sign2 = strtoul(temp_image_link_sign2, 0, 0);

    return true;
}

//int get_information(char *file_name, char* pic_dir, file_input *input_data)
int get_information(char *file_name, char* pic_dir, CondVar _m_data_signal)
//int CommonService::get_information(char *file_name, char* pic_dir, file_input *input_data)
{
    std::string line;
    std::ifstream infile(file_name);
    int idx_begin = 0;
    int idx_end = 0;
    char temp_db_type[2];
    unsigned int db_type = 0;
    const unsigned int request_type = 11;
    char link[SITE_LEN] = "\0";
    char site_image_link[SITE_LEN] = "\0";
    unsigned int image_link_sign1 = 0;
    unsigned int image_link_sign2 = 0;
    char image_name[128];
    char dir[2] = "/";
    char jpg[5] = ".jpg";
    std::string pic_name = "";
    unsigned int link_sign1 = 0;
    unsigned int link_sign2 = 0;
    int seg_idx = 0;
    int ignore_seg_idx1 = 2;
    int ignore_seg_idx2 = 5;
    int line_num = 0;
    while (std::getline(infile, line))
    {
        line_num++;
        //get db_type
        idx_end = line.find('\t');
        if (idx_end == std::string::npos)
        {
            ul_writelog(UL_LOG_WARNING, "idx_end = -1, line: %s", line.c_str());
            continue;
        }
        if (idx_end > MAX_BUF_LENGTH)
        {
            ul_writelog(UL_LOG_WARNING, "idx_end has exceed MAX_BUF_LENGTH line: %s", line.c_str());
            continue;
        }
        snprintf(temp_db_type, idx_end + 1, "%s", line.c_str());
        temp_db_type[idx_end] = '\0';
        db_type  = strtoul(temp_db_type, 0, 0);
        if (db_type == 0 || db_type == 1)
        {
            db_type += 1;
        }
        else
        {
            ul_writelog(UL_LOG_WARNING, "db_type is error, db_type: %d,\
                    line_num is: %d", db_type, line_num); 
            continue;
        }

        //get image_link_url
        idx_begin = idx_end + 1;

        idx_end = line.find('\t', idx_begin);
        if (idx_end == std::string::npos)
        {
            ul_writelog(UL_LOG_WARNING, "idx_end = -1, line: %s", line.c_str());
            continue;
        }
        if (idx_end > MAX_BUF_LENGTH)
        {
            ul_writelog(UL_LOG_WARNING, "idx_end has exceed MAX_BUF_LENGTH line: %s", line.c_str());
            continue;
        }
        memcpy(site_image_link, line.substr(idx_begin).c_str(), idx_end);
        site_image_link[idx_end - idx_begin] = '\0';

        //get image_sign1 image_sign2
        bool ret = get_image_sign(site_image_link, image_link_sign1, image_link_sign2);
        if (!ret)
        {
            ul_writelog(UL_LOG_WARNING, "get image_link_sign failed! line: %s", line.c_str());
            continue; 
        } 
        //get link_url
        idx_begin = idx_end + 1;

        seg_idx = 1;
        while (seg_idx < ignore_seg_idx1)        //  跳过前8个字段，到#9
        {
            idx_begin = line.find('\t', idx_begin);
            if (idx_begin == std::string::npos)
            {
                ul_writelog(UL_LOG_WARNING, "idx_begin = -1, line: %s", line.c_str());
                continue;
            }
            seg_idx++;
        }
        idx_begin = idx_begin + 1;
        idx_end = line.find('\t', idx_begin);
        if (idx_end == std::string::npos)
        {
            ul_writelog(UL_LOG_WARNING, "idx_end = -1, line: %s", line.c_str());
            continue;
        }
        if (idx_end > MAX_BUF_LENGTH)
        {
            ul_writelog(UL_LOG_WARNING, "idx_end exceed, line: %s", line.c_str());
            continue;
        }
        //memcpy(link, line.substr(idx_begin).c_str(), idx_end);
        snprintf(link, idx_end - idx_begin + 1, "%s", line.substr(idx_begin).c_str());
        make_key(link, link_sign1, link_sign2);
        //get image_raw data 
        idx_begin = idx_end + 1;
        seg_idx = 1;
        while (seg_idx < ignore_seg_idx2)        //  跳过前8个字段，到#9
        {
            idx_begin = line.find('\t', idx_begin);
            if (idx_begin == std::string::npos)
            {
                ul_writelog(UL_LOG_WARNING, "idx_begin = -1, line: %s", line.c_str());
                continue;
            }
            idx_begin += 1;
            seg_idx++;
        }
        //idx_end = line.find('\t', idx_begin);
        //if (idx_end != std::string::npos)
        //{
        //    ul_writelog(UL_LOG_WARNING, "idx_end = -1, line: %s", line.c_str());
        //    continue;
        //}
        //if (idx_end > MAX_BUF_LENGTH)
        //{
        //    ul_writelog(UL_LOG_WARNING, "idx_end exceed, line: %s", line.c_str());
        //    continue;
        //}

        snprintf(image_name, sizeof(image_name), "%s", line.substr(idx_begin).c_str());
        //pthread_mutex_lock(&g_data_num_lock);
        pic_name = pic_dir;   
        pic_name += dir;
        pic_name += image_name;
        pic_name += jpg;
        
        FILE * fp = NULL;
        fp = fopen(pic_name.c_str(), "rb");
        //int fp = open(pic_name.c_str(), O_RDONLY);
        if (fp == NULL)
        {
            ul_writelog(UL_LOG_WARNING, "fopen pic error, the line is: %s", line.c_str());
        }
        struct file_input temp;
        
        //图片存储位置 
        //char *image_raw_data = NULL;
        //image_raw_data = (char*)malloc(DATA_LEN);
        
        //读入图片
        try
        {
            ret = fread(temp.i_image_raw_data, DATA_LEN, 1, fp);
            //ret = read(fp, temp.i_image_raw_data, DATA_LEN);
            if (ret < 0)
            {
                ul_writelog(UL_LOG_WARNING, "read pic data error, the line is: %s", line.c_str());
                fclose(fp);
                exit(1);
            }
        }
        catch (...)
        {
            ul_writelog(UL_LOG_WARNING, "this line: %s has problem", line.c_str());
            continue;
        }
        
        temp.data_input(request_type, link, link_sign1, link_sign2, db_type,
                site_image_link, image_link_sign1, image_link_sign2);
        //free(image_raw_data);
        pthread_mutex_lock(&g_data_num_lock);
        g_file_input.push_back(temp);
        //wake up the thread who is waiting 
        _m_data_signal.signal(); 
        pthread_mutex_unlock(&g_data_num_lock);
        
        if (g_file_input.size() >= 500)
        {
            usleep(2000 * 1000);
        }
        memset(link, 0, sizeof(link));
        memset(site_image_link, 0, sizeof(site_image_link));
        fclose(fp);
    }

    return 0;
}

void* service_thread_func(void *targ)
{

    struct crawl_arg* parg = (struct crawl_arg*)targ;
    struct sockaddr_in addr;
    bzero(&addr, sizeof(sockaddr_in));
    addr.sin_addr.s_addr = inet_addr(parg->ip);
    addr.sin_family = AF_INET;
    addr.sin_port = htons(parg->port);
    CondVar _m_data_signal = parg->m_data_signal;
    int *_m_state = parg->m_state;
    
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        
        ul_writelog(UL_LOG_WARNING, "get socket fd fail, host is: %s,\
                port is: %d", parg->ip, parg->port);
        safe_exit();
    }
    int ret = connect(fd, (struct sockaddr*)&addr, sizeof(addr));
    while (ret < 0) {
        ret = connect(fd, (struct sockaddr*)&addr, sizeof(addr));
        ul_writelog(UL_LOG_WARNING, "server is not alive, host is: %s,\
                port is: %d", parg->ip, parg->port);
        usleep(5000 * 1000);
        //close(fd);
        //safe_exit();
    }   
    int writetimeout = parg->writetimeout;

    char reqbuf[BUF_SIZE];
    char tmpbuf[BUF_SIZE];

    nshead_t reqhead;
    reqhead.body_len  = sizeof(reqbuf);
    reqhead.magic_num = NSHEAD_MAGICNUM;

    file_input temp; 
    for (;;)
    {
        mc_pack_t * pack = mc_pack_open_w(2, reqbuf, sizeof(reqbuf), tmpbuf, sizeof(tmpbuf));
        pthread_mutex_lock(&g_data_num_lock);
        if (g_file_input.size() != 0)
        {
            temp = g_file_input.back(); 
            g_file_input.pop_back();
            pthread_mutex_unlock(&g_data_num_lock);
        } 
        else
        {
            if (*_m_state == STARTED)
            {
                ul_writelog(UL_LOG_DEBUG, "the data is null, wait");
                //time_t t2 = time(NULL);
                //std::cout<<"t2 time is "<<t2<<std::endl;
                _m_data_signal.wait(&g_data_num_lock); 
                //usleep(1000 * 5000);
                pthread_mutex_unlock(&g_data_num_lock);
                continue;
            }
            else 
            {
                break;
            }
        }
        ret =  mc_pack_put_uint32(pack, "request_type", temp.i_request_type);
        if (ret < 0)
        {
            ul_writelog(UL_LOG_WARNING, "put request_type error, the link is: %s", temp.i_link); 
            continue;
        }
        ret = mc_pack_put_uint32(pack, "db_type", temp.i_db_type);
        if (ret < 0)
        {
            ul_writelog(UL_LOG_WARNING, "put db_type error, the link is: %s", temp.i_link); 
            continue;
        }
        ret = mc_pack_put_str(pack, "link", temp.i_link);
        if (ret < 0)
        {
            ul_writelog(UL_LOG_WARNING, "put link error, the link is: %s", temp.i_link); 
            continue;
        }
        ret = mc_pack_put_uint32(pack, "link_sign1", temp.i_link_sign1);
        if (ret < 0)
        {
            ul_writelog(UL_LOG_WARNING, "put link_sign1 error, the link is: %s", temp.i_link); 
            continue;
        }
        ret = mc_pack_put_uint32(pack, "link_sign2", temp.i_link_sign2);
        if (ret < 0)
        {
            ul_writelog(UL_LOG_WARNING, "put link_sign2 error, the link is: %s", temp.i_link); 
            continue;
        }
        ret = mc_pack_put_str(pack, "site_image_link", temp.i_site_image_link);
        if (ret < 0)
        {
            ul_writelog(UL_LOG_WARNING, "put site_image_link error\
                    , the link is: %s", temp.i_link); 
            continue;
        }
        ret = mc_pack_put_uint32(pack, "image_link_sign1", temp.i_image_link_sign1);
        if (ret < 0)
        {
            ul_writelog(UL_LOG_WARNING, "put image_link_sign1 error\
                    , the link is: %s", temp.i_link); 
            continue;
        }
        ret = mc_pack_put_uint32(pack, "image_link_sign2", temp.i_image_link_sign2);
        if (ret < 0)
        {
            ul_writelog(UL_LOG_WARNING, "put image_link_sign2 error\
                    , the link is: %s", temp.i_link); 
            continue;
        }
        //if (strlen(temp.i_image_raw_data))
        //{
        //    ul_writelog(UL_LOG_WARNING, "the pic is null", temp.i_link); 
        //}
        ret = mc_pack_put_raw(pack, "image_raw_data", temp.i_image_raw_data, DATA_LEN);
        if (ret < 0)
        {
            ul_writelog(UL_LOG_WARNING, "put image_raw_data error,\
                    the link is: %s", temp.i_link); 
            continue;
        }
        mc_pack_t *re = mc_pack_put_object(pack, "");
        if (MC_PACK_PTR_ERR(re))
        {
            ul_writelog(UL_LOG_WARNING, "put trans_data error, the link is: %s", temp.i_link); 
            continue;
        }
        ret = nshead_write_ex(fd, &reqhead, reqbuf, writetimeout);
        //usleep(5000 * 1000);
        if (ret != 0) {
            ul_writelog(UL_LOG_WARNING, "nshead write error, the link is: %s", temp.i_link); 
            close(fd);
            safe_exit();
        }
        ul_writelog(UL_LOG_NOTICE, "nshead write success, the link is: %s", temp.i_link); 

        mc_pack_close(pack);
        memset(reqbuf, 0, sizeof(reqbuf));
        //usleep(50 * 1000);
    }
    close(fd);
    safe_exit();
    return NULL;

}
int CommonService::run()
{
    // ignore SIGPIPE
    signal(SIGPIPE, SIG_IGN);
    _m_state = STARTED;

    pthread_t thread_id[_conf.thread_num];
    struct crawl_arg* targ = new struct crawl_arg();
    snprintf(targ->ip, IP_LEN, "%s", _conf.server_host);
    targ->port = _conf.server_port;
    targ->readtimeout = _conf.read_timeout;
    targ->writetimeout = _conf.write_timeout;
    targ->m_data_signal = _m_data_signal;
    targ->m_state = &_m_state;

    for (unsigned int i = 0; i < _conf.thread_num; ++i)
    {
        int ret = ul_pthread_create(&thread_id[i], NULL, service_thread_func, targ);
        if (ret != 0) 
        {
            ul_writelog(UL_LOG_FATAL, "thread listen_thread_func create\
                  failed.[%m]");
            return -1;
        }
    }
    get_information(_conf.file_name, _conf.pic_dir, _m_data_signal); 
    ul_writelog(UL_LOG_NOTICE, "read data complete!");
    //time_t t1 = time(NULL);
    //std::cout<<"t1 time is "<<t1<<std::endl;
    _m_state = STOPPED;
    _m_data_signal.signal(); 

    for (unsigned int i = 0; i <= _conf.thread_num; ++i)
    {
        ul_pthread_join(thread_id[i], NULL);
    }

    return 1;
}





















/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
