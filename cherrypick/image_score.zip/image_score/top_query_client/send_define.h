/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file send_define.h
 * @author baixueyu(com@baidu.com)
 * @date 2015/12/14 16:22:44
 * @brief 
 *  
 **/

#ifndef  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_TOP_QUERY_CLIENT_SEND_DEFINE_H
#define  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_TOP_QUERY_CLIENT_SEND_DEFINE_H

const int DIR_LEN = 1024;
const int IP_LEN = 16;
const int SITE_LEN = 256;
const int DATA_LEN = 1024 * 512;
const int MAX_BUF_LENGTH = 1024; 
const int QUEUE_LEN = 500;
const int BUF_SIZE = 1024 * 1024;
#endif  //__SEND_DEFINE_H_

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
