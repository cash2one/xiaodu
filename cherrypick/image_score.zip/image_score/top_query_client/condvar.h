/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file convar.h
 * @author baixueyu(com@baidu.com)
 * @date 2015/11/16 11:06:52
 * @brief 
 *  
 **/

#ifndef  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_CONDVAR_H
#define  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_CONDVAR_H

#include <pthread.h>
#include <unistd.h>
#include <deque>
#include <iostream>
#include <vector>

#include "global.h"

class CondVar {
public:
    CondVar();
    ~CondVar();
    void wait(pthread_mutex_t* mutex);
    void signal();
    void broadcast();

private:
    pthread_cond_t _m_cond_var;
};

#endif  //__COMMONSERVICE_H_
