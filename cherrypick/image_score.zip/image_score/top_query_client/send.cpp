/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file send.cpp
 * @author baixueyu(com@baidu.com)
 * @date 2015/11/16 19:03:14
 * @brief 
 *  
 **/
#include "nshead.h"
#include "send.h"
#include "common_service.h"
#include "ul_log.h"
#include "ul_conf.h"
#include "ul_thr.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include "mc_pack.h"
#include <dirent.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <iostream>

SendConfig g_conf;

void read_log_conf(Ul_confdata* pcf, LogConfig* pconf)
{
    //2. 读取log信息、打开log
    if (!ul_getconfstr(pcf, "LOG_PATH", pconf->logpath))
    {
        snprintf(pconf->logpath, SCORE_MAX_DIR_LEN, "./log");
    }
    if (!ul_getconfstr(pcf, "LOG_NAME",  pconf->logname))
    {
        snprintf(pconf->logname, SCORE_MAX_DIR_LEN, "%s", "defaultlog.");
    }
    if (!ul_getconfint(pcf, "LOG_LEVEL", &(pconf->loglevel)))
    {
        pconf->loglevel = UL_LOG_ALL;
    }
    if (!ul_getconfint(pcf, "LOG_SIZE", &(pconf->logsize)))
    {
        pconf->logsize = 500000;
    }

    pconf->log_stat.events = pconf->loglevel;
    pconf->log_stat.spec = 0;
    pconf->log_stat.to_syslog = 0;
}

bool read_service_conf(Ul_confdata *pcf, ServiceConfig* pconf)
{
    if (!ul_getconfuint(pcf, "THREAD_NUM", &(pconf->thread_num)))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [THREAD_NUM] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set THREAD_NUM %d.", pconf->thread_num);
    
    if (!ul_getconfstr(pcf, "server_host", pconf->server_host))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [server_host] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set server_host %s.", pconf->server_host);

    if (!ul_getconfuint(pcf, "server_port", &(pconf->server_port)))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [server_port] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set server_port %d.", pconf->server_port);

    if (!ul_getconfuint(pcf, "readtimeout", &(pconf->read_timeout)))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [readtimeout] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set readtimeout %d.", pconf->read_timeout);

    if (!ul_getconfuint(pcf, "writetimeout", &(pconf->write_timeout)))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [writetimeout] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set writetimeout %d.", pconf->write_timeout); 
    if (!ul_getconfuint(pcf, "encode_type", &(pconf->encode_type)))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [encode_type] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set encode_type %d.", pconf->encode_type);

    if (!ul_getconfstr(pcf, "file_name", pconf->file_name))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [file_name] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set file_name %s.", pconf->file_name);
    
    if (!ul_getconfstr(pcf, "pic_dir", pconf->pic_dir))
    {
        ul_writelog(UL_LOG_FATAL, "read conf item [pic_dir] failed.");
        return false;
    }
    ul_writelog(UL_LOG_NOTICE, "set pic_dir %s.", pconf->pic_dir);

    return true;
}

bool readconf(Ul_confdata *pcf, SendConfig *pconf)
{
    if (!read_service_conf(pcf, &(pconf->svc_config)))
    {
        return false;
    }
    return true;
}

bool init(SendConfig *pconf)
{
     //1. 打开conf文件
    Ul_confdata *pcf = NULL;
    pcf = ul_initconf(100);
    if (NULL == pcf)
    {
        ul_writelog(UL_LOG_FATAL, "\n[Fatal Error] init buf for basic config file error!\n");
        return false;
    }

    int ret = ul_readconf("conf/", "send.conf", pcf);
    if (ret < 0) 
    {   
        ul_writelog(UL_LOG_FATAL, "load config file error!\n");
        return false;
    }
    //2. 读取log信息、打开log
    read_log_conf(pcf, &(pconf->log_conf));
    ul_writelog(UL_LOG_NOTICE, "use log: path=%s file=%s\n", pconf->log_conf.logpath, 
            pconf->log_conf.logname);

    ret = ul_openlog(pconf->log_conf.logpath, pconf->log_conf.logname, 
            &(pconf->log_conf.log_stat), pconf->log_conf.logsize);  

    if (ret < 0) 
    {
        ul_writelog(UL_LOG_FATAL, "\n[Fatal Error] open log fail!\n");   
        ul_freeconf(pcf);
        return false;
    }
    if (!readconf(pcf, pconf))
    {
        ul_writelog(UL_LOG_FATAL, "\n[Fatal Error] read conf fail!\n");
        ul_freeconf(pcf);
        return false;
    }
    return true;

}

int main(int argc, char **argv)
{
    signal(SIGPIPE, SIG_IGN);
    init(&g_conf);

    char* service_name = "send";
    ServiceConfig send_svc_config;
    send_svc_config = g_conf.svc_config;

    CommonService svc(service_name, send_svc_config, &g_conf.log_conf.log_stat);
    svc.run();
    
    return 1;
}
/*
{

    





        const char *ip = "10.46.189.34";
        unsigned short port = 7002;

        string Dir = "/home/users/baixueyu/score_service/app/search/video/test/pic/";
        DIR *pDir = opendir(Dir.c_str());
        struct dirent * entry = NULL;
       if (NULL == pDir)
       {
           return false;
       }
      int sym = 0; 
            struct sockaddr_in addr;
            bzero(&addr, sizeof(sockaddr_in));
            addr.sin_addr.s_addr = inet_addr(ip);
            addr.sin_family = AF_INET;
            addr.sin_port = htons(port);
            
            int fd = socket(AF_INET, SOCK_STREAM, 0);
            if(fd < 0) {
                    return -1;
            }
            
            int ret = connect(fd, (struct sockaddr*)&addr, sizeof(addr));
            if(ret < 0) {
                    close(fd);
                    return -1; 
            }   
          

       while (NULL != (entry = readdir(pDir)))
        {
            if(sym == 50)
            {
                sleep(1);
                sym = 0;
            }
            if (entry->d_type == 4)
                continue;

            sym++;
            if ( sym == 2)
            {
            }
            //cout<< entry->d_name<<endl;

            string real_dir = Dir + string(entry->d_name); 
            cout<<real_dir<<endl;
            FILE * fp;
            //real_dir = "/home/users/baixueyu/score_service/app/search/video/test/pic2/2-470923124,766318434.jpg";
            real_dir = "/home/users/baixueyu/score_service/app/search/video/test/output/adff.jpg";

            fp = fopen(real_dir.c_str(), "rb");
            //图片存储位置 
            char *pic = NULL;
            pic = (char*)malloc(128000);
            //读入图片
            int ret = fread(pic, 128000, 1, fp);
            if(ret < 0)
            {
               perror("fread error. \n");
               exit(1);
            }
            
            int timeout = 1000;
            nshead_t reqhead;
            size_t bufsize = 138000;
            char reqbuf[bufsize];
            //strcpy(reqbuf, "hello");
            
            reqhead.body_len  = sizeof(reqbuf) + 1;
            reqhead.magic_num = NSHEAD_MAGICNUM;
            //mcpack
            //char data[bufsize];
            char tmpbuf[bufsize];
            mc_pack_t * pack = mc_pack_open_w(2, reqbuf, sizeof(reqbuf), tmpbuf, sizeof(tmpbuf));
            
            mc_pack_put_uint32(pack, "request_type", 3);
            mc_pack_put_str(pack, "link", entry->d_name);
            mc_pack_put_uint32(pack, "link_sign1", 2176805760);
            mc_pack_put_uint32(pack, "link_sign2", 3601096322);
            mc_pack_put_str(pack, "site_image_link", "http://wiki.baidu.com/pages/viewpage.action?pageId=150421880_1)");
            mc_pack_put_uint32(pack, "image_link_sign1", 2176805761);
            mc_pack_put_uint32(pack, "image_link_sign2", 3601096323);
            mc_pack_put_raw(pack, "image_raw_data", pic, 128000);
            mc_pack_put_object(pack, "");
         
            ret = nshead_write(fd, &reqhead, reqbuf, timeout);
            if(ret != 0) {
                    printf("nshead_write failed, %d\n", ret);
                    close(fd);
                    return -1;
            }
            free(pic);
            pic = NULL;
            break;
        }
       return 0; 




        
//        nshead_t reshead;
//        ret = nshead_read(fd, &reshead, resbuf, bufsize, timeout);
//        if(ret != 0) {
//                printf("nshead_read failed, %d\n", ret);
//                close(fd);
//                return -1;
//        }
//        
//        printf("recv (%d) bytes from server: (%s)\n",
//        reshead.body_len,
//        resbuf);
//        close(fd);
//        return 0;
}
















*/



/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
