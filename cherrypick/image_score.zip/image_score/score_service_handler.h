/***************************************************************************
 * 
 * Copyright (c) 2011 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/

/**
 * @file AladinServiceHandler.h
 * @author qizhiwei(com@baidu.com)
 * @date 2011/01/18 13:01:12
 * @brief 
 *  
 **/

#ifndef  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_SCORE_SERVICE_HANDLER_H
#define  APP_SEARCH_VIDEO_VIDEODATA_SERVICE_IMAGE_SCORE_SCORE_SERVICE_HANDLER_H

#include "common_service.h"
#include "mysql_operator.h"
#include <vector> 
#include "mc_pack.h"
#include <string.h>
#include "score_input.h"
#include "score_define.h"
//#include "opencv2/legacy/legacy.hpp"
#include "opencv2/opencv.hpp"
#include "opencv2/core/mat.hpp"
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"

class ScoreServiceHandler : public ServiceHandler
{
public:

    ScoreServiceHandler(int thread_index, const char* mysql_host, unsigned int mysql_port, 
            char* mysql_user, char* mysql_passwd, char* db_name, unsigned int
            encode_type) : _thread_index(thread_index)
    {
        //snprintf(_ip, strlen(mysql_host) + 1, "%s", mysql_host);
        memcpy(_ip, mysql_host, strlen(mysql_host));
        _port = mysql_port;
        snprintf(_user, strlen(mysql_user) + 1, "%s", mysql_user);
        snprintf(_passwd, strlen(mysql_passwd) + 1, "%s", mysql_passwd);
        snprintf(_db_name, strlen(db_name) + 1, "%s", db_name);
        _encode_type = encode_type;
    }

    virtual ~ScoreServiceHandler();

    // ��ʼ��
    bool init(/*bsl::syspool* mempool*/);

    // ͳһ��������
    int handle(WorkSocket& socket);

    bool ScoreServiceHandler::get_query(WorkSocket& socket);
    int ScoreServiceHandler::init_basic_data();
    bool ScoreServiceHandler::init_data_for_pc();
    bool ScoreServiceHandler::init_data_for_wise();
    bool ScoreServiceHandler::init_data_for_recommend();
    int ScoreServiceHandler::get_response();
    bool ScoreServiceHandler::get_image_link_sign(const char* image_link_url,
            unsigned int &_image_link_sign1, unsigned int &_image_link_sign2);
    bool ScoreServiceHandler::send_response_for_pc();
    int ScoreServiceHandler::send_response(WorkSocket &socket);
    bool ScoreServiceHandler::send_response_for_wise(WorkSocket &socket);
    bool ScoreServiceHandler::send_response_for_recommend(WorkSocket &socket);
    int ScoreServiceHandler::cal_feature(cv::Mat img);
    int ScoreServiceHandler::max_min(int a, int b, int c);

    //  ��ҳ�Ƽ�ʹ��
    int cal_feature_mainpage(const cv::Mat & img);
    int has_black_border(const cv::Mat & gray_img);
    int has_bad_width_height_ratio(const cv::Mat & gray_img);
    bool init_data_for_recommend_mainpage();
    bool send_response_for_recommend_mainpage();

private:
    int _thread_index;
    char _compack_buf_req[BUF_SIZE_REQ];
    char _compack_buf_res[BUF_SIZE_RES];
    //���յ�������
    //1������pc����Ƶ����������¼ 2������wise����Ƶ���ݷ��� 3������������������
    ImageInput _image_input;
    char *_table_type;
    uint32_t _table_num;
    char _table_name[SITE_LEN];
    char _site_image_link[SITE_LEN];
    char _link[SITE_LEN];
    uint32_t _link_sign1;
    uint32_t _link_sign2;
    uint32_t _image_link_sign1;
    uint32_t _image_link_sign2;

    //get feature
    cv::Mat _original_img;
    cv::Mat _gray_img;
    int _height;
    int _width;
    
    int _height_thres;
    int _width_thres;

    int _nchannel;
    float _features[4];
    int _image_score;
    //
    static double _s_w[4];
    int _if_changed_top; 
    int _if_changed_left; 

    //mysql 
    char _ip[16];
    uint16_t _port;
    char _user[32];
    char _passwd[32];
    char _db_name[32];
    uint32_t _encode_type;
    char _query[256];
    Indexdboperator * _m_mysql_operator;
    //time for output
    time_t _t_old;
    time_t _t_new;
    char _time_old[11];
    char _filename[256];
    char _time_new[11];
 
};

class ScoreServiceFactory : public ServiceFactory
{
public:
    ScoreServiceFactory()
    {
    }

    ServiceHandler* create(int thread_index, char* mysql_host, unsigned int mysql_port, 
            char* mysql_user, char* mysql_passwd, char* db_name, unsigned int encode_type)
    {
        ScoreServiceHandler* handler = new ScoreServiceHandler(thread_index, mysql_host,
                mysql_port, mysql_user, mysql_passwd, db_name, encode_type);
        if (!handler->init(/*&mem_pool*/))
        {
            ul_writelog(UL_LOG_FATAL, "init lsearch_service_handler failed");
            delete handler;
            return NULL;
        }
        return handler;
    }

};

#endif  //__ALADIN_SERVICE_HANDLER_H_
/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
