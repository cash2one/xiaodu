/***************************************************************************
 * 
 * Copyright (c) 2012 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/

/**
 * @file ScoreServiceHandler.cpp
 * @author jiangguohua(com@baidu.com)
 * @date 2012/06/18 18:58:14
 * @brief 
 *  
 **/

#include "score_service_handler.h"
#include "mc_pack.h"
#include <string>
#include <sstream>
#include <stdio.h>
#include <sstream>
#include "mysql_operator.h"

pthread_mutex_t g_save_spider_info_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t g_save_videomap_info_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t g_save_mainpage_info_lock = PTHREAD_MUTEX_INITIALIZER;

bool ScoreServiceHandler::get_image_link_sign(const char* image_link_url,
        unsigned int &_image_link_sign1, unsigned int &_image_link_sign2)
{
    std::string link_url = image_link_url;
    int url_len = strlen(image_link_url);
    int sign_begin = 0;
    int sign_end = 0;

    char *u = "u";
    char *u1 = "=";
    char *f = "&";
    char *f1 = "f";
    char url[3];
    char url1[3];

    for (int i = 0; i < url_len; i++)
    {
        snprintf(url, 2, "%s", image_link_url + i);
        snprintf(url1, 2, "%s", image_link_url + i + 1);

        if (strcmp(url, u) == 0 && strcmp(url1, u1) == 0)
        {
            sign_begin = i + 2;
        }
        if (strcmp(url, f) == 0 && strcmp(url1, f1) == 0)
        {
            sign_end = i - sign_begin;
            break;
        } 
    }
    if (sign_begin >= sign_end)
    {
        ul_writelog(UL_LOG_WARNING, "get image_link_sign sign_begin >= sign_end failed!\
                , image_url: %s", image_link_url);
        return false;
    }

    char temp_sign_str[22] = "\0";
    char temp_image_link_sign1[11] = "\0";
    char temp_image_link_sign2[11] = "\0";

    snprintf(temp_sign_str, sign_end + 2, "%s", link_url.substr(sign_begin).c_str());
    std::string temp_string_str = temp_sign_str;
    int idx = temp_string_str.find(",");
    if (idx == -1)
    {
        ul_writelog(UL_LOG_WARNING, "get image_link_url has some problem!\
                , image_url: %s", image_link_url);
        return false;
    }
    snprintf(temp_image_link_sign1, idx + 2, "%s", temp_sign_str);
    snprintf(temp_image_link_sign2, idx + 2, "%s", temp_sign_str + idx + 1);
    _image_link_sign1 = strtoul(temp_image_link_sign1, 0, 0);
    _image_link_sign2 = strtoul(temp_image_link_sign2, 0, 0);

    return true;

}
// ��ʼ��
bool ScoreServiceHandler::init(/*bsl::syspool* mempool*/)
{
    _table_type = NULL;
    _link_sign1 = 0;
    _link_sign2 = 0;
    _image_link_sign1 = 0;
    _image_link_sign2 = 0;
    _height = 0;
    _width = 0;
    _image_score = 0; 
    _if_changed_top = 0;
    _if_changed_left = 0;
    _m_mysql_operator = new Indexdboperator();
    if (_m_mysql_operator->init(_ip, _port, _user, _passwd, _db_name, _encode_type))
    {
        ul_writelog(UL_LOG_FATAL, "the database init fail");
    }

    //time related
    _t_old = time(0);
    strftime(_time_old, sizeof(_time_old), "%Y%m%d%H", localtime(&_t_old));
    _time_old[11]  = '\0';

    return true;

}

ScoreServiceHandler::~ScoreServiceHandler()
{
}

int ScoreServiceHandler::max_min(int a, int b, int c)
{
    if (a >= b)
    {
        if (c > a)
        {
            return c - b;
        }
        else if (b > c)
        {
            return a - c;
        }
        else 
        {
            return a - b;
        }
    }
    else
    {
        if (c > b)
        {
            return c - a;
        }
        else if (a > c)
        {
            return b - c;
        }
        else
        {
            return b - a;
        }
    }
}

//hsv_color_mean edge_mean dft_val w_h_ratio
//double ScoreServiceHandler::_s_w[4] = {0.02036073, 0.05767602, 0.00047548, 0.01354828};
//double ScoreServiceHandler::_s_w[4] = {0.02036073, 0.05767602, 0.0015, 0.01354828};
double ScoreServiceHandler::_s_w[4] = {0.022, 0.060, 0.0015, 0.01354828};

int ScoreServiceHandler::cal_feature(cv::Mat img)
{
    //ͼ���ǻҶ�ͼ��ֱ�Ӹ�һ��ƽ��ֵ 50��
    try
    {
        if (img.channels() < 3)
        {
            _features[0] = 50;
            ul_writelog(UL_LOG_WARNING, "the image is gray, link: %s", _link);
            return 1;
 
        }
        cv::cvtColor(img, _gray_img, CV_BGR2GRAY);
        _height_thres = _original_img.rows / 6;
        _width_thres = _original_img.cols / 6;
        _height = _gray_img.rows;
        _width = _gray_img.cols;
        _nchannel = img.channels(); 
        //ͼƬ̫С
        if (_width <= 50 && _height <= 50 && _if_changed_left < 1 && _if_changed_top < 1)
        {
            _features[0] = 0.1;
            ul_writelog(UL_LOG_TRACE, "image is too small, the feature is 0, link: %s", _link);
            return 1;
        }
        //��̫�̣�������
        if (_width <= 55 && _if_changed_left < 1 && _if_changed_top < 1)
        {
            _features[0] = 4;
            ul_writelog(UL_LOG_TRACE, "image's width less then 55, the feature is 4, \
                    link: %s", _link);
            return 1;
        }
        //����һ��
        if ((_width * 1.0 / _height) == 1)
        {
            _features[0] = 8;
            ul_writelog(UL_LOG_TRACE, "image with the same width and height, the \
                    feature is 8, link: %s", _link);
            return 1;
        }
        //ȫ��ȫ��
        cv::Scalar gray_img_mean = mean(_gray_img);
        if (gray_img_mean.val[0] <= 20 || gray_img_mean.val[0] >= 230)
        {
            _features[0] = 2;
            ul_writelog(UL_LOG_TRACE, "image all write or all black, \
                    the feature: 2  link: %s", _link);
            return 1;
        }
        //���ܱ����ؽ����ж�
        int border1 = 7;
        cv::Mat bm_top(_gray_img, cv::Rect(border1, 0, _width - 2 * border1, border1));
        //cv::Mat bm_bottom(_gray_img, cv::Rect(border1, height - border1, width - 2 * border1, border1));
        cv::Mat bm_left(_gray_img, cv::Rect(0, border1, border1, _height - 2*border1));
        //cv::Mat bm_right(_gray_img, cv::Rect(width - border1, border1, border1, height - 2 * border1));
 
        cv::Scalar bm_top_mean = mean(bm_top);
        //cv::Scalar bm_bottom_mean = mean(bm_bottom);
        cv::Scalar bm_left_mean = mean(bm_left);
        //cv::Scalar bm_right_mean = mean(bm_right);
 
        if (bm_top_mean.val[0] < 2)
        {
            _if_changed_top += 1;
            if (_if_changed_top * border1 > _height_thres)
            {
                _features[0] = 10;
                ul_writelog(UL_LOG_TRACE, "image top edge mean less 10, \
                        the feature is 10, link: %s", _link);
                return 2;
            }
            int border2 = border1 * _width / _height;
            cv::Mat img_temp(img, cv::Rect(border2, border1, _width - 2 * border2, 
                        _height - 2 * border1));
            int ret = cal_feature(img_temp);
            return ret;
        }
        //if (bm_bottom_mean.val[0] < 10)
        //{
        //    features[0] = 10;
        //    ul_writelog(UL_LOG_WARNING, "image bottom edge mean less 10, 
        //    the feature is 10, link: %s", _link);
        //    return 2;
        //}
        if (bm_left_mean.val[0] < 2)
        {
            _if_changed_left += 1;
            if (_if_changed_left * border1 > _width_thres)
            {
                _features[0] = 10;
                ul_writelog(UL_LOG_TRACE, "image top edge mean less 10, \
                        the feature is 10, link: %s", _link);
                return 2;
            }
            int border2 = border1 * _height / _width;
            cv::Mat img_temp(img, cv::Rect(border1, border2, _width - 2 * border1, 
                        _height - 2 * border2));
            int ret = cal_feature(img_temp);
            return ret;
        }
        //if (bm_right_mean.val[0] < 10)
        //{
        //    features[0] = 10;
        //    ul_writelog(UL_LOG_WARNING, "image right edge mean less 10, 
        //    the feature is 10, link: %s", _link);
        //    return 2;
        //}
        //features of image color   
 
        cv::Mat temp_image_data(_height, _width, CV_8UC1);
 
        for (int h_i = 0; h_i < _height; h_i++)
        {
            for (int w_j = 0; w_j < _width; w_j++)
            {
                int b = img.at<uchar>(h_i, w_j * _nchannel + 0);
                int g = img.at<uchar>(h_i, w_j * _nchannel + 1);
                int r = img.at<uchar>(h_i, w_j * _nchannel + 2);
                int m_m = max_min(b, g, r);
                temp_image_data.at<uchar>(h_i, w_j) = m_m;
            }
        }
        cv::Scalar color_mean = mean(temp_image_data);
        if (color_mean.val[0] >= 0)
        {
            _features[0] = color_mean.val[0];
            ul_writelog(UL_LOG_TRACE, "image color mean is: %f, link: %s width: %d, \
                    height: %d", color_mean.val[0], _link, _width, _height);
        }
        else
        {
            ul_writelog(UL_LOG_FATAL, "cal image color feature fail, link: %s", _link);
        }
  
        //edge of image color
        cv::Mat detected_edges;
        cv::blur(_gray_img, detected_edges, cv::Size(3, 3));
        cv::Canny(detected_edges, detected_edges, 50, 3, 3); 
        cv::Scalar canny_mean = mean(detected_edges);
 
        if (canny_mean.val[0] >= 0)
        {
            //_features[1] = color_mean.val[0];
            _features[1] = canny_mean.val[0];
            ul_writelog(UL_LOG_TRACE, "image edge mean is: %f, link: %s \
                    ", canny_mean.val[0], _link);
        }
        else
        {
            ul_writelog(UL_LOG_FATAL, "cal image edge feature fail, link: %s", _link);
        }
        //the fft of image 
        cv::Mat padded;
        int nheight = cv::getOptimalDFTSize(_height);
        int nwidth = cv::getOptimalDFTSize(_width);
        cv::copyMakeBorder(_gray_img, padded, 0, nheight - _height, 0, \
                nwidth - _width, cv::BORDER_CONSTANT, cv::Scalar::all(0));
        //cv::imwrite("padded.jpg", padded);
 
        cv::Mat planes[] = {cv::Mat_<float>(padded), cv::Mat::zeros(padded.size(), CV_32F) };
        
        cv::Mat complexi;
        cv::merge(planes, 2, complexi);
        cv::dft(complexi, complexi, cv::DFT_COMPLEX_OUTPUT); 
        
        cv::Scalar fft_sum = sum(complexi);
        int all = _width * _height * 2;
        float fft_value = (fft_sum.val[0] + fft_sum.val[1]) / all;
        _features[2] = fft_value;
        ul_writelog(UL_LOG_TRACE, "image fft mean is: %f, link: %s", fft_value, _link);       
 
        //cv::split(complexi, planes);
        //
        //cv::magnitude(planes[0], planes[1], planes[0]);
        //cv::Mat magI = planes[0];
        //
        //magI += cv::Scalar::all(1); 
        //cv::log(magI, magI);
 
        //magI = magI(cv::Rect(0, 0, magI.cols & (-2), magI.rows & (-2)));
        //cv::normalize(magI, magI, 1, 0, CV_MINMAX);
        //magI = 256. * magI;
        //cv::Scalar fft_mean = mean(magI);
        //
        //if (fft_mean.val[0] >= 0)
        //{
        //    features[2] = fft_mean.val[0];
        //    ul_writelog(UL_LOG_WARNING, "image fft mean is: %f, link: %s", fft_mean.val[0], link);
        //}
        //else
        //{
        //    ul_writelog(UL_LOG_FATAL, "cal image fft feature fail, link: %s", link);
        //}
        
        //get w_h ratio : ����ͼ??
        float w_h_ratio = _width * 1.0 / _height;
        if (w_h_ratio >= 1.33 && w_h_ratio <= 1.78)
        {
            _features[3] = 250;
            ul_writelog(UL_LOG_TRACE, "image w_h feature is: 250, link: %s", _link);
        }
        else if (w_h_ratio < 1.33)
        {
            float temp_res = 1.0 / (1.334 - w_h_ratio);
            _features[3] = temp_res;
            ul_writelog(UL_LOG_TRACE, "image w_h feature is: %f, link: %s", _features[3], _link); 
        }
        else if (w_h_ratio > 1.78)
        {
            float temp_res = 1.0 / (w_h_ratio - 1.777);
            _features[3] = temp_res;
            ul_writelog(UL_LOG_TRACE, "image w_h feature is: %f, link: %s", _features[3], _link); 
        }
        //ignore w_h_ratio
        _features[3] = 60;
        }
    catch (...)
    {
        ul_writelog(UL_LOG_FATAL, "the pic has some problem, \
                image_link1: %I10u, %I10u", _link_sign1, _link_sign2);
        return -1;
    }

    //cv::imwrite("test.jpg", detected_edges);
    //cv::imwrite("gray.jpg", _gray_img);
    return 0;
}

bool ScoreServiceHandler::init_data_for_pc()
{
    //get table type
    if (_image_input._db_type == DB_TYPE_SPIDER)
    {
        _table_type = "spider_url";
    }
    else if (_image_input._db_type == DB_TYPE_VIDEOMAP)
    {
        _table_type = "videomap_url";
    }
    else
    {
        ul_writelog(UL_LOG_FATAL, "get wrong db_type"); 
        return -1;
    }
    //get information for log 
    memcpy(_link, _image_input._link, SITE_LEN);
    _link_sign1 = _image_input._link_sign1;
    _link_sign2 = _image_input._link_sign2;
    _image_link_sign1 = _image_input._image_link_sign1;
    _image_link_sign2 = _image_input._image_link_sign2;
    memcpy(_site_image_link, _image_input._site_image_link, SITE_LEN);
    //get image date
    std::vector<char> vectordata(_image_input._image_raw_data, _image_input._image_raw_data\
            + _image_input._data_len);
    _original_img = cv::imdecode(vectordata, CV_LOAD_IMAGE_COLOR);
    
    //FILE *stream = NULL;
    //if ((stream = fopen("a.jpg", "wb+")) == NULL) /* open file TEST.$$$ */
    //{
    //    fprintf(stderr, "Cannot open output file.\n");
    //}
    //fwrite(_image_input._image_raw_data, DATA_LEN, 1, stream);
    
    return true;

}

bool ScoreServiceHandler::init_data_for_wise()
{
    //get information for log 
    memcpy(_link, _image_input._link, SITE_LEN);
    //get image date
    std::vector<char> vectordata(_image_input._image_raw_data, _image_input._image_raw_data\
            + _image_input._data_len);
    _original_img = cv::imdecode(vectordata, CV_LOAD_IMAGE_COLOR);

    return true;
}

bool ScoreServiceHandler::init_data_for_recommend()
{
    //get information for image
    _link_sign1 = _image_input._link_sign1;
    _link_sign2 = _image_input._link_sign2;
    memcpy(_site_image_link, _image_input._site_image_link, SITE_LEN);
    get_image_link_sign(_site_image_link, _image_link_sign1, _image_link_sign2);
    //get image date
    std::vector<char> vectordata(_image_input._image_raw_data, _image_input._image_raw_data\
            + _image_input._data_len);
    _original_img = cv::imdecode(vectordata, CV_LOAD_IMAGE_COLOR);
    return true;
}

bool ScoreServiceHandler::init_data_for_recommend_mainpage()
{
    //get information for log 
    memcpy(_link, _image_input._link, SITE_LEN);
    _link_sign1 = _image_input._link_sign1;
    _link_sign2 = _image_input._link_sign2;
    _image_link_sign1 = _image_input._image_link_sign1;
    _image_link_sign2 = _image_input._image_link_sign2;
    memcpy(_site_image_link, _image_input._site_image_link, SITE_LEN);
    //get image date
    std::vector<char> vectordata(_image_input._image_raw_data, _image_input._image_raw_data\
            + _image_input._data_len);
    _original_img = cv::imdecode(vectordata, CV_LOAD_IMAGE_COLOR);
    return true;
}

int ScoreServiceHandler::init_basic_data()
{
    if (_image_input._request_type == REQUEST_TYPE_PC ||
            _image_input._request_type == REQUEST_TYPE_TOPQUERY ||
            _image_input._request_type == REQUEST_TYPE_RECOMMEND)
    {
        if (!init_data_for_pc())
        {
            return -1;
        }
    }
    else if (_image_input._request_type == REQUEST_TYPE_WISE) 
    {
        if (!init_data_for_wise())
        {
            return -1;
        }
    }
    else if (_image_input._request_type == REQUEST_TYPE_RECOMMEND_MAINPAGE)
    {
        if (!init_data_for_recommend_mainpage())
        {
            return -1;
        }
    }
    //else if (_image_input._request_type == REQUEST_TYPE_RECOMMEND) 
    //{
    //    if (!init_data_for_recommend())
    //    {
    //        return -1;
    //    }
    //}
    else 
    {
        return -1;
    }
    return 0;
}

/**
 * @brief �ж��Ƿ�Ϊ���кڱߵ�ͼƬ
 * @param gray_img [in]
 * @param width [in]
 * @param height [in]
 * @return 1�ǣ�0��
 */
int ScoreServiceHandler::has_black_border(const cv::Mat & gray_img)
{
    int width = gray_img.cols;
    int height = gray_img.rows;
    int count_black_pixel = 0;            //  black pixel������(�Ҷ�ֵ<20�ж�Ϊblack pixel)
    int count_border_pixel = width * 2;   //  ����border pixel��������pixel����

    //  �����border black pixel���������в�ͼ
    cv::Mat top_border(gray_img, cv::Rect(0, 0, width, 2));
    count_black_pixel = cv::countNonZero(top_border < 20);
    if (count_black_pixel * 1.0 / count_border_pixel > 0.60)
    {
        return 1;
    }

    //  �����border black pixel���������в�ͼ
    cv::Mat bottom_border(gray_img, cv::Rect(0, height - 2, width, 2));
    count_black_pixel = cv::countNonZero(bottom_border < 20);
    if (count_black_pixel * 1.0 / count_border_pixel > 0.60)
    {
        return 1;
    }
    return 0;
}

/**
 * @brief �ж��Ƿ�Ϊ�ߴ��������ͼƬ
 *  175:98  =   1.786
 *  16:9    =   1.778
 *  175:105 =   1.667
 *  4:3     =   1.333
 * @return 0��1��
 */
int ScoreServiceHandler::has_bad_width_height_ratio(const cv::Mat & gray_img)
{
    int width = gray_img.cols;
    int height = gray_img.rows;
    float ratio = width * 1.0 / height;
    float max_ratio = 1.80;
    float min_ratio = 1.50;

    if (ratio > max_ratio || ratio < min_ratio)
    {
        return 1;
    }
    return 0;
}

/**
 * @brief ������ҳ��֣�������ϸ�
 * @return 0 LR���ԣ�-1����������-�˹�����
 */
int ScoreServiceHandler::cal_feature_mainpage(const cv::Mat & img)
{
    try
    {
        //  1. �˹����Թ���
        //  ת�ɻҶ�
        if (img.channels() < 3)
        {
            _features[0] = 50;
            ul_writelog(UL_LOG_WARNING, "the image is gray, link: %s", _link);
            return 1;
        }
        cv::cvtColor(img, _gray_img, CV_BGR2GRAY);

        //  �ж��Ƿ�ߴ��������
        if (has_bad_width_height_ratio(_gray_img))
        {
            _features[0] = 50;
            return 2;
        }

        //  �ж��Ƿ��кڱ�
        if (has_black_border(_gray_img))
        {
            _features[0] = 40;
            return 2;
        }

        //  2. LR���Դ��
        return cal_feature(img);
    }
    catch (...)
    {
        ul_writelog(UL_LOG_FATAL, "cal_feature_mainpage() failed, "
                "image_link: %I10u, %I10u", _link_sign1, _link_sign2);
        return -1;
    }
    ul_writelog(UL_LOG_TRACE, "cal_feature_mainpage()");
    return -1;
}

int ScoreServiceHandler::get_response()
{
    //��ʼ����������
    int ret = init_basic_data();
    if (ret == -1)
    {
        ul_writelog(UL_LOG_FATAL, "get wrong db_type"); 
        return -1;
    }
     
    cv::Mat img(_original_img);
    if (_original_img.empty())
    {
        ul_writelog(UL_LOG_WARNING, "the image_raw_data is empty, \
                image_link1: %I10u, %I10u", _link_sign1, _link_sign2);
        return -1;
    }

    //  add by shaanlan@baidu.com, 20160421
    if (_image_input._request_type == REQUEST_TYPE_PC ||
            _image_input._request_type == REQUEST_TYPE_TOPQUERY ||
            _image_input._request_type == REQUEST_TYPE_RECOMMEND)
    {
        ret = cal_feature(img);
        //ret = cal_feature_mainpage(img);
    }
    else if (_image_input._request_type == REQUEST_TYPE_RECOMMEND_MAINPAGE)
    {
        //  ret: 0 - LR����, -1 - ����, other - �˹�����
        ret = cal_feature_mainpage(img);
    }

    //get result 
    int w_len = (sizeof(_s_w) / sizeof(_s_w[0]));
    double temp_image_score = 0;
    if (ret == 0)
    {
        double prob = -4.36576092;
        for (int i = 0; i < w_len; i++) 
        {
            prob += _s_w[i] * _features[i];
        }
        prob *= -1;
        prob = exp(prob);
        prob += 1;
        prob = 1.0 / prob;
        temp_image_score = prob;
        if (_if_changed_top > 0 || _if_changed_left > 0)
        {
            temp_image_score *= 100;
            int max_change = _if_changed_left > _if_changed_top ?\
                             _if_changed_left : _if_changed_top;
            if (temp_image_score <= 5 * max_change)
            {
                temp_image_score = temp_image_score > 5 ?\
                                   temp_image_score : 5; 
            }
            else
            {
                temp_image_score += -5 * max_change + 5;
            }
            ul_writelog(UL_LOG_TRACE, "get image score by LR learning with frame, \
                    the score is: %f, link: %s", temp_image_score, _link);
        }
        else 
        {
            temp_image_score *= 100;
            ul_writelog(UL_LOG_TRACE, "get image score by LR learning without frame, \
                    the score is: %f, link: %s", temp_image_score, _link);
        }

        //debug
        {
            //output feature
            char* feat_name[4] = {"color_mean", "edge_mean", "fft", "w_h_ratio"};
            std::ostringstream oss;
            oss.str(" ");
            for (int i = 0; i < w_len; i++) 
            {
                oss << "\t" 
                    << feat_name[i] 
                    << "("
                    << _s_w[i] 
                    << "*" 
                    <<  _features[i]
                    << ")";
            }
            std::string feat_fmt = oss.str();
            ul_writelog(UL_LOG_TRACE, "LR_FETT%s\t%f\t%u,%u", 
                    feat_fmt.c_str(), temp_image_score, _image_link_sign1, _image_link_sign2);
        }
    }
    else if (ret == -1)
    {
        return 0;
    }
    else
    {
        temp_image_score = _features[0];
        ul_writelog(UL_LOG_TRACE, "get image score by Artificial strategy, \
                the score is: %f, link: %s", temp_image_score, _link);
    }
    _image_score = int(temp_image_score);
    if (_image_score < 0 || _image_score > 99)
    {
        _if_changed_top = 0;
        _if_changed_left = 0;
        ul_writelog(UL_LOG_FATAL, "the pic has some problem,\
                link is:%s image_link1: %I10u_%I10u", _link, _link_sign1, _link_sign2); 
        char pic_path[50] = {0};
        snprintf(pic_path, 50, "./pic_bad/%I10u_%I8u.jpg", _image_link_sign1, _image_link_sign2);
        cv::imwrite(pic_path, _original_img); 
        //get_response();
    }
    //���¹�λ
    _if_changed_top = 0;
    _if_changed_left = 0;
    return 0;
}

bool ScoreServiceHandler::send_response_for_pc()
{
    int len = 0;
    int table_name_len = 0;
    int ret = 0;
    int query_len = 0;
    FILE *stream = NULL;

    //time related
    _t_new = time(0); 
    strftime(_time_new, sizeof(_time_new), "%Y%m%d%H", localtime(&_t_new));
    _time_new[11]  = '\0';
    //test only
    //sprintf(_time_new, "2015120815");
    //_time_new[11]  = '\0';

    //just for recommend
    if (_image_input._request_type == REQUEST_TYPE_RECOMMEND)
    {
        if ((_height * 1.0 / _width) <= 0.5 || (_height * 1.0 / _width) >= 0.625)
        {
            _image_score -= 30;
            if (_image_score <= 0)
            {
                _image_score = 10;
            }
        }
    }

    if (!strcmp(_time_old, _time_new))
    {
        snprintf(_time_old, sizeof(_time_old), "%s", _time_new);
    }
    
    _table_num = (_link_sign1 + _link_sign2) % 64 + 1;
    len = strlen(_table_type);
    snprintf(_table_name, sizeof(_table_name), "%s%d", _table_type, _table_num); 
    table_name_len = strlen(_table_name);
    _table_name[table_name_len] = '\0';
    
    //use index_db
    //snprintf(_query, sizeof(_query), "%u\t%u\t%d\t%u\t%u\n", \
            _link_sign1, _link_sign2, _image_score, _image_link_sign1, _image_link_sign2); 

    snprintf(_query, sizeof(_query), "%u\t%u\t%d\n", \
            _link_sign1, _link_sign2, _image_score);
    
    if (_image_input._db_type == DB_TYPE_SPIDER)
    {
        _table_type = "spider_url";
        char *dir = "./indexdb_client_spider_imagescore/data/url_imagescore_spider_";
        snprintf(_filename, sizeof(_filename), "%s%s.txt", dir, _time_new);
        if ((stream = fopen(_filename, "a+")) == NULL) /* open file TEST.$$$ */
        { 
            if ((stream = fopen(_filename, "w+")) == NULL)
            {
                fprintf(stderr, "Cannot open output file.\n");
                return false;
            }
        }
        pthread_mutex_lock(&g_save_spider_info_lock); 
        query_len = strlen(_query);
        fwrite(_query, query_len, 1, stream);
        fclose(stream);
        pthread_mutex_unlock(&g_save_spider_info_lock);
    }
    else if (_image_input._db_type == DB_TYPE_VIDEOMAP)
    {
        _table_type = "videomap_url";
        char *dir = "./indexdb_client_videomap_imagescore/data/url_imagescore_videomap_";
        snprintf(_filename, sizeof(_filename), "%s%s.txt", dir, _time_new);
        if ((stream = fopen(_filename, "a+")) == NULL) /* open file TEST.$$$ */
        { 
            if ((stream = fopen(_filename, "w+")) == NULL)
            {
                fprintf(stderr, "Cannot open output file.\n");
                return false;
            }
        }
        pthread_mutex_lock(&g_save_videomap_info_lock); 
        query_len = strlen(_query);
        fwrite(_query, query_len, 1, stream);
        fclose(stream);
        pthread_mutex_unlock(&g_save_videomap_info_lock);

    }
   
    //use mysql directly
    //sprintf(_query, "update %s set image_score = %f where link_sign1 = %I10u, link_sign2 = %I10u", _table_name, _image_score, _link_sign1, _link_sign2); 
    //sprintf(_table_name, "%s", "image_score");
    //_table_name[11] = '\0';

    //snprintf(_query,  256, "insert into image_score values('%s', %I10u, %I10u, '%s', %I10u,\
        %I10u, 100)", _link, _link_sign1, _link_sign2,
    //        _site_image_link, _image_link_sign1, _image_link_sign2); 
    //int query_len = strlen(_query);
    //_m_mysql_operator->sendquery(_query, query_len); 

    return true;
}

/**
 * @brief ������ݸ���ҳ�Ƽ�ʹ��
 */
bool ScoreServiceHandler::send_response_for_recommend_mainpage()
{
    int len = 0;
    int table_name_len = 0;
    int ret = 0;
    int query_len = 0;
    FILE *stream = NULL;

    //time related
    _t_new = time(0); 
    strftime(_time_new, sizeof(_time_new), "%Y%m%d%H", localtime(&_t_new));
    _time_new[11]  = '\0';

    if (!strcmp(_time_old, _time_new))
    {
        snprintf(_time_old, sizeof(_time_old), "%s", _time_new);
    }

    snprintf(_query, sizeof(_query), "%u\t%u\t%d\n", \
            _link_sign1, _link_sign2, _image_score); 
    if (_image_input._request_type == REQUEST_TYPE_RECOMMEND_MAINPAGE)
    {
        //  add by shaanlan@baidu.com, 20160422
        _table_type = "mainpage_url";
        char *dir = "./data/indexdb_client_mainpage_imagescore/url_imagescore_mainpage_";
        snprintf(_filename, sizeof(_filename), "%s%s.txt", dir, _time_new);
        if ((stream = fopen(_filename, "a+")) == NULL) /* open file TEST.$$$ */
        { 
            if ((stream = fopen(_filename, "w+")) == NULL)
            {
                ul_writelog(UL_LOG_WARNING, "Cannot open output file:%s.", _filename);
                return false;
            }
        }
        pthread_mutex_lock(&g_save_mainpage_info_lock); 
        query_len = strlen(_query);
        fwrite(_query, query_len, 1, stream);
        fclose(stream);
        pthread_mutex_unlock(&g_save_mainpage_info_lock);
    }

    return true;
}

bool ScoreServiceHandler::send_response_for_wise(WorkSocket &socket)
{
    char tmp_buf_res[BUF_SIZE_REQ];
    char buf_res[BUF_SIZE_REQ];
    mc_pack_t *ppack = mc_pack_open_w(2, buf_res,
            sizeof(buf_res), tmp_buf_res, sizeof(tmp_buf_res));
    if (MC_PACK_PTR_ERR(ppack))
    {
        ul_writelog(UL_LOG_WARNING, 
                "fail to open pack[%s][%d]", __FILE__, __LINE__);
        return false;
    }
    
    mc_pack_put_uint32(ppack, "request_type", _image_input._request_type);
    mc_pack_put_str(ppack, "link", _image_input._link);
    mc_pack_put_uint32(ppack, "image_score", (uint32_t)_image_score);

    int buf_res_len = mc_pack_get_size(ppack);
    
    if (socket.write(buf_res, buf_res_len) < 0)
    {
        return false;
    }

    return true;
}

bool ScoreServiceHandler::send_response_for_recommend(WorkSocket &socket)
{
    //GET DATA INTO REDIS


    return true;
}

int ScoreServiceHandler::send_response(WorkSocket &socket)
{
    if (_image_input._request_type == REQUEST_TYPE_PC ||
            _image_input._request_type == REQUEST_TYPE_TOPQUERY ||
            _image_input._request_type == REQUEST_TYPE_RECOMMEND)
    {
        if (!send_response_for_pc())
        {
            return -1;
        }
    }
    else if (_image_input._request_type == REQUEST_TYPE_WISE) 
    {
        if (!send_response_for_wise(socket))
        {
            return -1;
        }
    }
    else if (_image_input._request_type == REQUEST_TYPE_RECOMMEND_MAINPAGE)
    {
        if (!send_response_for_recommend_mainpage())
        {
            return -1;
        }
    }
    //else if (_image_input._request_type == REQUEST_TYPE_RECOMMEND) 
    //{
    //    if (!send_response_for_recommend(socket))
    //    {
    //        return -1;
    //    }
    //}
    else 
    {
        return -1;
    }
    return 1;
}

int ScoreServiceHandler::handle(WorkSocket& socket)
{

    struct timeval s;
    struct timeval e;
    time_t s1;
    time_t s2;
    time_t s3;
    int ret = 0;
    //1. Get query
    gettimeofday(&s, NULL);
    ret = get_query(socket);
    if (!ret)
    {
        ul_writelog(UL_LOG_FATAL, "failed to get query");
        return -1;
    }
    gettimeofday(&e, NULL);
    s1 = TIMEDIFF(s, e);
    // get response
    ret = get_response();
    gettimeofday(&e, NULL);
    s2 = TIMEDIFF(s, e);
    if (ret < 0)
    {
        ul_writelog(UL_LOG_WARNING, "the picture is null");
        return 0;
    }

    //3. send response
    ret = send_response(socket);
    gettimeofday(&e, NULL);
    s3 = TIMEDIFF(s, e);

    ul_writelog(UL_LOG_TRACE, "get query cost %ld us", s1);
    ul_writelog(UL_LOG_TRACE, "get response cost %ld us", s2);
    ul_writelog(UL_LOG_TRACE, "send response cost %ld us", s3);

    return 1;
}

bool ScoreServiceHandler::get_query(WorkSocket& socket)
{
    // ����I/O
    int len = socket.read(_compack_buf_req, BUF_SIZE_REQ);
    if (len < 0)
    {
        ul_writelog(UL_LOG_WARNING, "get socket data wrong, len less then 0");
        return false;
    }
    if (len == 0)
    {
        ul_writelog(UL_LOG_WARNING, "query body len cannot be zero");
        return false;
    }
    //m_logid = socket.LogId; // logid
    char *default_value = "www.baidu.com";
    int default_len = strlen(default_value);

    // ���mc_pack
    char buffer[BUF_SIZE_REQ];
    buffer[0] = '\0';
    
    mc_pack_t *mc_pack = mc_pack_open_r(_compack_buf_req, len, buffer, sizeof(buffer));

    int ret = _image_input.unserials(mc_pack);
    if (!ret) 
    {
        ul_writelog(UL_LOG_WARNING, "get mc_pack req error!");
        return false;
    }
    return true;

}


/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
